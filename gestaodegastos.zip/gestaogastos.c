#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <locale.h>
// Gest�o de Gastos

// Vari�veis //
int i, n;
float somaall=0, somall=0;

// Estruturas //
struct login{
	char nmr[20]; // Guarda o nome/n�mero
	char ppass[100]; // Guarda a password
};
struct login l; 

struct registo{
	char nmr[20]; // Cria a guarda o nome/n�mero
	char ppass[100]; // Cria e guarda a password
};
struct registo r; 

struct gastos{
	char mes[12]; // Guarda o m�s
	float din; // Guarda o dinheiro
};
struct gastos t;

struct ddm{
	float agua; // Guarda o dinheiro gasto em �gua
	float luz; // Guarda o dinheiro gasto em luz
	float gaz; // Guarda o dinheiro gasto em gaz
	float renda; // Guarda o dinheiro gasto em renda
	float condominio; // Guarda o dinheiro gasto em condom�nio
	float supermercado; // Guarda o dinheiro gasto em supermercado
};
struct ddm dd;

struct dau{
	float combus; // Guarda o dinheiro gasto em combust�vel
	float inspecao; // Guarda o dinheiro gasto em inspe��o
	float selo; // Guarda o dinheiro gasto em selo
	float seguro; // Guarda o dinheiro gasto em seguro
	float portagem; // Guarda o dinheiro gasto em portagens
};
struct dau da;

struct ret{
	float tpu; // Guarda o dinheiro gasto em transportes p�blicos
	float restau; // Guarda o dinheiro gasto em restaura��o
	float saude; // Guarda o dinheiro gasto em sa�de
};
struct ret re;

// Ficheiros //
FILE *rt;
FILE *md;
FILE *dm;
FILE *du;
FILE *ot;

// Desenvolvimento... //
void stats2(){
	system("cls");
	printf("\n---> Estat�sticas do m�s <---");
	char opc;
		do{
			printf("\n\n-> 1| Dinheiro Gasto Em Despesas Dom�sticas ");
			printf("\n-> 2| Dinheiro Gasto Em Despesas Autom�vel ");
			printf("\n-> 3| Dinheiro Gasto Transportes P�blicos ");
			printf("\n-> 4| Dinheiro Gasto Restaura��o ");
			printf("\n-> 5| Dinheiro Gasto Sa�de ");
			printf("\n-> 6| Total De Dinheiro Gasto ");
			printf("\n-> 7| Dinheiro Que Sobrou ");
			printf("\n\n-> 0| Voltar ");
			opc=getch();
			switch(opc){
				case '1':
					system("cls");
					float somadd=0;
					printf("\n---> Dinheiro Gasto Despesas Dom�sticas <---");
					dm = fopen("ddomesticas.txt", "r");
					while(fscanf(dm, "%f %f %f %f %f %f", &dd.agua, &dd.luz, &dd.gaz, &dd.renda, &dd.condominio, &dd.supermercado)!=EOF){
						somadd=dd.agua+dd.luz+dd.gaz+dd.renda+dd.condominio+dd.supermercado;
					}
						printf("\n\n-> Dinheiro Gasto: %.2f$", somadd);
					fclose(dm);
					getch();
					stats2();
					break;
					
				case '2':
					system("cls");
					float somada=0;
					printf("\n---> Dinheiro Gasto Despesas Autom�vel <---");
					du = fopen("dauto.txt", "r");
					while(fscanf(du, "%f %f %f %f %f %f", &da.combus, &da.inspecao, &da.selo, &da.seguro, &da.portagem)!=EOF){
						somada=da.combus+da.inspecao+da.selo+da.seguro+da.portagem;
					}
						printf("\n\n-> Dinheiro Gasto: %.2f$", somada);
					fclose(du);					
					getch();
					stats2();
					break;
					
				case '3':
					system("cls");
					printf("\n---> Dinheiro Gasto Transportes P�blicos <---");
					ot = fopen("outros.txt", "r");
					while(fscanf(ot, "%f %f %f", &re.tpu, &re.restau, &re.saude)!=EOF){
						printf("\n\n-> Dinheiro Gasto: %.2f$", re.tpu);
					}
					fclose(ot);
					getch();
					stats2();
					break;
					
				case '4':
					system("cls");
					printf("\n---> Dinheiro Gasto Restaura��o <---");
					ot = fopen("outros.txt", "r");
					while(fscanf(ot, "%f %f %f", &re.tpu, &re.restau, &re.saude)!=EOF){
						printf("\n\n-> Dinheiro Gasto: %.2f$", re.restau);
					}
					fclose(ot);					
					getch();
					stats2();
					break;
					
				case '5':
					system("cls");
					printf("\n---> Dinheiro Gasto Sa�de <---");
					ot = fopen("outros.txt", "r");
					while(fscanf(ot, "%f %f %f", &re.tpu, &re.restau, &re.saude)!=EOF){
						printf("\n\n-> Dinheiro Gasto: %.2f$", re.saude);
					}
					fclose(ot);					
					getch();
					stats2();
					break;
					
				case '6':
					system("cls");
					printf("\n---> Total De Dinheiro Gasto <---");
					dm = fopen("ddomesticas.txt", "r");
					du = fopen("dauto.txt", "r");
					ot = fopen("outros.txt", "r");
					while(fscanf(dm, "%f %f %f %f %f %f", &dd.agua, &dd.luz, &dd.gaz, &dd.renda, &dd.condominio, &dd.supermercado)!=EOF){
						while(fscanf(du, "%f %f %f %f %f %f", &da.combus, &da.inspecao, &da.selo, &da.seguro, &da.portagem)!=EOF){
							while(fscanf(ot, "%f %f %f", &re.tpu, &re.restau, &re.saude)!=EOF){
								somaall=dd.agua+dd.luz+dd.gaz+dd.renda+dd.condominio+dd.supermercado+da.combus+da.inspecao+da.selo+da.seguro+da.portagem+re.tpu+re.restau+re.saude;
							}
						}
					}
						printf("\n\n-> Dinheiro Gasto: %.2f$", somaall);
					fclose(dm);
					fclose(du);
					fclose(ot);
					getch();
					stats2();
					break;
					
				case '7':
					system("cls");
					printf("\n---> Dinheiro Que Sobrou <---");
					dm = fopen("ddomesticas.txt", "r");
					du = fopen("dauto.txt", "r");
					ot = fopen("outros.txt", "r");
					md = fopen("dinr.txt", "r");
					while(fscanf(dm, "%f %f %f %f %f %f", &dd.agua, &dd.luz, &dd.gaz, &dd.renda, &dd.condominio, &dd.supermercado)!=EOF){
						while(fscanf(du, "%f %f %f %f %f %f", &da.combus, &da.inspecao, &da.selo, &da.seguro, &da.portagem)!=EOF){
							while(fscanf(ot, "%f %f %f", &re.tpu, &re.restau, &re.saude)!=EOF){
								while(fscanf(md, "%f", &t.din)!=EOF){
									somall=t.din-somaall;
								}
							}
						}
					}
						printf("\n\n-> Dinheiro Sobra: %.2f$", somall);					
					fclose(dm);
					fclose(du);
					fclose(ot);
					fclose(md);										
					getch();
					stats2();
					break;
					
					case '0':
						bemvindos();
						break;						
			}
		}while(opc!='0');
}

void dau(){
	system("cls");
	printf("\n---> Despesas Autom�vel <---");
	char opc;
		do{
			printf("\n\n-> 1| Combust�vel ");
			printf("\n-> 2| Inspe��o ");
			printf("\n-> 3| Selo ");
			printf("\n-> 4| Seguro ");
			printf("\n-> 5| Portagens ");
			printf("\n\n-> 0| Voltar");
			opc=getch();
			switch(opc){
				case '1':
					system("cls");
					printf("\n---> Gasto em Combust�vel <---");
					du = fopen("dauto.txt", "a");
					printf("\n\n-> Pre�o: ");
					scanf("%f", &da.combus);
					fprintf(du, "%.2f\n", da.combus);
					fclose(du);
					getch();
					dau();
					break;
					
				case '2':
					system("cls");
					printf("\n---> Gasto em Inspe��o <---");
					du = fopen("dauto.txt", "a");
					printf("\n\n-> Pre�o: ");
					scanf("%f", &da.inspecao);
					fprintf(du, "%.2f\n", da.inspecao);
					fclose(du);
					getch();
					dau();
					break;
					
				case '3':
					system("cls");
					printf("\n---> Gasto em Selo <---");
					du = fopen("dauto.txt", "a");
					printf("\n\n-> Pre�o: ");
					scanf("%f", &da.selo);
					fprintf(du, "%.2f\n", da.selo);
					fclose(du);
					getch();
					dau();
					break;
					
				case '4':
					system("cls");
					printf("\n---> Gasto em Seguro <---");
					du = fopen("dauto.txt", "a");
					printf("\n\n-> Pre�o: ");
					scanf("%f", &da.seguro);
					fprintf(du, "%.2f\n", da.seguro);
					fclose(du);
					getch();
					dau();
					break;					
					
				case '5':
					system("cls");
					printf("\n---> Gasto em Portagens <---");
					du = fopen("dauto.txt", "a");
					printf("\n\n-> Pre�o: ");
					scanf("%f", &da.portagem);
					fprintf(du, "%.2f\n", da.portagem);
					fclose(du);
					getch();
					dau();
					break;
					
				case '0':
					bemvindos();
					break;																				
			}
		}while(opc!='0');			
}

void ddm(){
	system("cls");
	printf("\n---> Despesas Dom�sticas <---");
	char opc;
		do{
			printf("\n\n-> 1| �gua ");
			printf("\n-> 2| Luz ");
			printf("\n-> 3| Gaz ");
			printf("\n-> 4| Renda ");
			printf("\n-> 5| Condom�nio ");
			printf("\n-> 6| Supermercado ");
			printf("\n\n-> 0| Voltar");
			opc=getch();
			switch(opc){
				case '1':
					system("cls");
					printf("\n---> Gasto de �gua <---");
					dm = fopen("ddomesticas.txt", "a");
					printf("\n\n-> Pre�o: ");
					scanf("%f", &dd.agua);
					fprintf(dm, "%.2f\n", dd.agua);
					fclose(dm);
					getch();
					ddm();
					break;
					
				case '2':
					system("cls");
					printf("\n---> Gasto de Luz <---");
					dm = fopen("ddomesticas.txt", "a");
					printf("\n\n-> Pre�o: ");
					scanf("%f", &dd.luz);
					fprintf(dm, "%.2f\n", dd.luz);
					fclose(dm);
					getch();
					ddm();
					break;
					
				case '3':
					system("cls");
					printf("\n---> Gasto de Gaz <---");
					dm = fopen("ddomesticas.txt", "a");
					printf("\n\n-> Pre�o: ");
					scanf("%f", &dd.gaz);
					fprintf(dm, "%.2f\n", dd.gaz);
					fclose(dm);
					getch();
					ddm();
					break;
					
				case '4':
					system("cls");
					printf("\n---> Gasto de Renda <---");
					dm = fopen("ddomesticas.txt", "a");
					printf("\n\n-> Pre�o: ");
					scanf("%f", &dd.renda);
					fprintf(dm, "%.2f\n", dd.renda);
					fclose(dm);
					getch();
					ddm();
					break;
					
				case '5':
					system("cls");
					printf("\n---> Gasto de Condom�nio <---");
					dm = fopen("ddomesticas.txt", "a");
					printf("\n\n-> Pre�o: ");
					scanf("%f", &dd.condominio);
					fprintf(dm, "%.2f\n", dd.condominio);
					fclose(dm);
					getch();
					ddm();
					break;
					
				case '6':
					system("cls");
					printf("\n---> Gasto de Supermercado <---");
					dm = fopen("ddomesticas.txt", "a");
					printf("\n\n-> Pre�o: ");
					scanf("%f", &dd.supermercado);
					fprintf(dm, "%.2f\n", dd.supermercado);
					fclose(dm);
					getch();
					ddm();
					break;
					
				case '0':
					bemvindos();
					break;																																
			}
		}while(opc!='0');			
}

void bemvindos(){
	system("cls");
	printf("\n---> Bem vindo/a %s <---", l.nmr);
	char opc;
		do{
			printf("\n\n-> 1| Dinheiro recebido ");
			printf("\n\n-> 2| Despesas Dom�sticas ");
			printf("\n-> 3| Despesas Autom�vel ");
			printf("\n-> 4| Transportes P�blicos ");
			printf("\n-> 5| Restaura��o ");
			printf("\n-> 6| Sa�de ");
			printf("\n\n-> 9| Estat�sticas ");
			printf("\n-> 0| Voltar");
			opc=getch();
			switch(opc){
				case '1':
					system("cls");
					printf("\n---> Dinheiro recebido <---");
					md = fopen("dinr.txt", "a");
					printf("\n\n-> M�s(1/12): ");
					fflush(stdin);
					gets(t.mes);
					printf("-> Dinheiro: ");
					scanf("%f", &t.din);
					fprintf(md, "%s %.2f\n", t.mes, t.din);
					fclose(md);
					bemvindos();
					getch();
					break;
				
				case '2':
					ddm();
					break;
					
				case '3':
					dau();
					break;
				
				case '4':
					system("cls");
					printf("\n---> Gasto em Transportes P�blicos <---");
					ot = fopen("outros.txt", "a");
					printf("\n\n-> Pre�o: ");
					scanf("%f", &re.tpu);
					fprintf(ot, "%.2f\n", re.tpu);
					fclose(ot);
					getch();					
					bemvindos();
					break;
					
				case '5':
					system("cls");
					printf("\n---> Gasto em Restaura��o <---");
					ot = fopen("outros.txt", "a");
					printf("\n\n-> Pre�o: ");
					scanf("%f", &re.restau);
					fprintf(ot, "%.2f\n", re.restau);
					fclose(ot);
					getch();					
					bemvindos();
					break;
					
				case '6':
					system("cls");
					printf("\n---> Gasto em Sa�de <---");
					ot = fopen("outros.txt", "a");
					printf("\n\n-> Pre�o: ");
					scanf("%f", &re.saude);
					fprintf(ot, "%.2f\n", re.saude);
					fclose(ot);
					getch();					
					bemvindos();
					break;
					
				case '9':
					stats2();
					break;						
			}
		}while(opc!='0');
}

// Login & Registo //
void login(){
	system("cls");
		rt = fopen("login.txt", "r");
		printf("\n---> Login <---");
		printf("\n\n-> Nome de utilizador ");
		printf("\n-> Nome: ");
		fflush(stdin);
		gets(l.nmr);
		printf("-> Password: ");
		fflush(stdin);
		gets(l.ppass);
			while(fscanf(rt, "%s %s", r.nmr, r.ppass)!=EOF)
			if(!strcmp(r.nmr, l.nmr))
				if(!strcmp(r.ppass, l.ppass)){
					bemvindos();
				}
	fclose(rt);
	getch();
}

void registo(){
	system("cls");
		printf("\n---> Registar <---");
		rt = fopen("login.txt","a");
		printf("\n\n-> Nome de utilizador ");
		printf("\n-> Nome: ");
		fflush(stdin);
		gets(r.nmr);
		printf("-> Password: ");
		fflush(stdin);
		gets(r.ppass);
	fprintf(rt, "%s %s\n", r.nmr, r.ppass);
	fclose(rt);
	getch();
}

// Admin //
void apagaradmin(){
	system("cls");
	char opc;
	printf("\n---> Admin - Apagar ficheiros <---");
	printf("\n\n-> Os ficheiros v�o ser apagados!");
	printf("\n-> PRETENDE CONTINUAR? (s/n): ");
	opc=getch();
	
	if(toupper(opc)=='S'){
		rt = fopen("login.txt", "w");
		md = fopen("dinr.txt", "w");
		dm = fopen("ddomesticas.txt", "w");
		du = fopen("dauto.txt", "w");
		ot = fopen("outros.txt", "w");
		fclose(rt);
		fclose(md);
		fclose(dm);
		fclose(du);
		fclose(ot);
		printf("\n\n-> Os ficheiros foram apagados.");
		getch();	
		}	
	system("cls");	
}

void adminmenu(){
	system("cls");
	char opc;
	do{
		printf("\n---> Admin - Comandos <---");
		printf("\n\n-> 1| Apagar ficheiros ");
		printf("\n\n-> 0| Voltar ao menu principal");
		opc=getch();
		switch(opc){
			case '1': 
				apagaradmin();
				break;	
		}
	}while(opc!='0');
}

void admin(){
	system("cls");
	int pass, user;
	printf("\n---> Admin - Acesso Restrito <---");
	printf("\n\n-> N�mero de acesso: ");
	scanf("%d", &user);
	printf("-> Password: ");
	scanf("%d", &pass);
		if(( user=123 ) && ( pass==321 ))
			adminmenu();
}

// Menu Principal //
void mp(){
	char opc;
	do{
		system("cls");
		printf("\n---> Gest�o de Gastos <---");
		printf("\n\n-> 1| Login ");
		printf("\n-> 2| Registar ");
		printf("\n\n-> 0| SAIR ");
		opc=getch();
		switch(opc){
			case 'a':
				admin();
				break;
				
			case '2': 
				registo();
				break;
				
			case '1': 
				login();
				break;	
		}
	}while(opc!='0');
}

int main(){
	setlocale(LC_ALL, "portuguese");
	system("color 71");
	mp();
	getch();
	system("cls");
	printf("\n-> Trabalho realizado por Gon�alo Rodrigues da Silva | 1021269");
}
