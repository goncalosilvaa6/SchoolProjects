<?php

$user = $_POST["user"];
$pass = $_POST["pass"];

if ($user == "admin" && $pass == "admin") {
    include "../entrar/admin.html";
}
else {
    include "login.html";
} 

?>