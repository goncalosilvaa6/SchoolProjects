

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- HEAD -->
    <!-- META -->
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- TITLE -->
        <title>Construction</title>
    <!-- CSS / ICONS -->
        <link rel="shortcut icon" href="img/logo_favicon.png">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/footer.css">
        <link rel="stylesheet" href="css/blog.css">
        <link rel="stylesheet" href="css/loader.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
</head>
<body>
    <!-- HEADER -->
        <header>
            <?php include('hfconnectors/header.php') ?>
        </header>
    <!-- MAIN -->
        <main>
            <div class="fundo-blog ">
                <div class="container-fluid">
                    <div class="titulo-blog mb-4">
                        Const<b>ruction</b> BLOG
                    </div>
                    <div class="row">
                        <div class="col-12 col-md-4">
                            <div class="card mb-3" style="max-width: 540px;">
                                <div class="row g-0">
                                    <div class="col-md-4">
                                        <img src="img/bonec.png" class="img-fluid rounded-start" alt="...">
                                    </div>
                                        <div class="col-md-8">
                                            <div class="card-body">
                                                <h5 class="card-title">Marcelo</h5>
                                                    <p class="card-text">Very good joob.<3 </p>
                                                    <p class="card-text"><small class="text-muted">Last updated 6 mins ago</small></p>
                                            </div>
                                        </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 col-md-4">
                            <div class="card mb-3" style="max-width: 540px;">
                                <div class="row g-0">
                                    <div class="col-md-4">
                                        <img src="img/bonec.png" class="img-fluid rounded-start" alt="...">
                                    </div>
                                        <div class="col-md-8">
                                            <div class="card-body">
                                                <h5 class="card-title">Jorge Calado</h5>
                                                    <p class="card-text">Very Nice!!</p>
                                                    <p class="card-text"><small class="text-muted">Last updated 20 mins ago</small></p>
                                            </div>
                                        </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 col-md-4">
                            <div class="card mb-3" style="max-width: 540px;">
                                <div class="row g-0">
                                    <div class="col-md-4">
                                        <img src="img/bonec.png" class="img-fluid rounded-start" alt="...">
                                    </div>
                                        <div class="col-md-8">
                                            <div class="card-body">
                                                <h5 class="card-title">Tito</h5>
                                                    <p class="card-text">Nice work, love it <3 </p>
                                                    <p class="card-text"><small class="text-muted">Last update 43 mins ago</small></p>
                                            </div>
                                        </div>
                                </div>
                            </div>
                        </div>  
                    </div>
                </div>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12 col-md-4">
                            <div class="card mb-3" style="max-width: 540px;">
                                <div class="row g-0">
                                    <div class="col-md-4">
                                        <img src="img/bonec.png" class="img-fluid rounded-start" alt="...">
                                    </div>
                                        <div class="col-md-8">
                                            <div class="card-body">
                                                <h5 class="card-title">Manuel Silva</h5>
                                                    <p class="card-text">Adorei o trabalho do estefanio. </p>
                                                    <p class="card-text"><small class="text-muted">Last updated 32 mins ago</small></p>
                                            </div>
                                        </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 col-md-4">
                            <div class="card mb-3" style="max-width: 540px;">
                                <div class="row g-0">
                                    <div class="col-md-4">
                                        <img src="img/bonec.png" class="img-fluid rounded-start" alt="...">
                                    </div>
                                        <div class="col-md-8">
                                            <div class="card-body">
                                                <h5 class="card-title">Hélder Conduto</h5>
                                                    <p class="card-text">Trabalhadores muito simpáticos</p>
                                                    <p class="card-text"><small class="text-muted">Last updated 22 mins ago</small></p>
                                            </div>
                                        </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 col-md-4">
                            <div class="card mb-3" style="max-width: 540px;">
                                <div class="row g-0">
                                    <div class="col-md-4">
                                        <img src="img/bonec.png" class="img-fluid rounded-start" alt="...">
                                    </div>
                                        <div class="col-md-8">
                                            <div class="card-body">
                                                <h5 class="card-title">Cristiano Ronaldo</h5>
                                                    <p class="card-text">Esta TOP! </p>
                                                    <p class="card-text"><small class="text-muted">Last update 11 mins ago</small></p>
                                            </div>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12 col-md-4">
                            <div class="card mb-3" style="max-width: 540px;">
                                <div class="row g-0">
                                    <div class="col-md-4">
                                        <img src="img/bonec.png" class="img-fluid rounded-start" alt="...">
                                    </div>
                                        <div class="col-md-8">
                                            <div class="card-body">
                                                <h5 class="card-title">Quim Colatra</h5>
                                                    <p class="card-text">Espetacular, pessoal 5 estrelas! </p>
                                                    <p class="card-text"><small class="text-muted">Last updated 53 mins ago</small></p>
                                            </div>
                                        </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 col-md-4">
                            <div class="card mb-3" style="max-width: 540px;">
                                <div class="row g-0">
                                    <div class="col-md-4">
                                        <img src="img/bonec.png" class="img-fluid rounded-start" alt="...">
                                    </div>
                                        <div class="col-md-8">
                                            <div class="card-body">
                                                <h5 class="card-title">Bino</h5>
                                                    <p class="card-text">Trabalhadores de confiança!!</p>
                                                    <p class="card-text"><small class="text-muted">Last updated 41 mins ago</small></p>
                                            </div>
                                        </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 col-md-4">
                            <div class="card mb-3" style="max-width: 540px;">
                                <div class="row g-0">
                                    <div class="col-md-4">
                                        <img src="img/bonec.png" class="img-fluid rounded-start" alt="...">
                                    </div>
                                        <div class="col-md-8">
                                            <div class="card-body">
                                                <h5 class="card-title">Rato</h5>
                                                    <p class="card-text">Equipa muito profissional </p>
                                                    <p class="card-text"><small class="text-muted">Last update 55 mins ago</small></p>
                                            </div>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12 col-md-4">
                            <div class="card mb-3" style="max-width: 540px;">
                                <div class="row g-0">
                                    <div class="col-md-4">
                                        <img src="img/bonec.png" class="img-fluid rounded-start" alt="...">
                                    </div>
                                        <div class="col-md-8">
                                            <div class="card-body">
                                                <h5 class="card-title">José Cid</h5>
                                                    <p class="card-text">Estadia Top! </p>
                                                    <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
                                            </div>
                                        </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 col-md-4">
                            <div class="card mb-3" style="max-width: 540px;">
                                <div class="row g-0">
                                    <div class="col-md-4">
                                        <img src="img/bonec.png" class="img-fluid rounded-start" alt="...">
                                    </div>
                                        <div class="col-md-8">
                                            <div class="card-body">
                                                <h5 class="card-title">Lili Caneças</h5>
                                                    <p class="card-text">5 estrelas.</p>
                                                    <p class="card-text"><small class="text-muted">Last updated 16 mins ago</small></p>
                                            </div>
                                        </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 col-md-4">
                            <div class="card mb-3" style="max-width: 540px;">
                                <div class="row g-0">
                                    <div class="col-md-4">
                                        <img src="img/bonec.png" class="img-fluid rounded-start" alt="...">
                                    </div>
                                        <div class="col-md-8">
                                            <div class="card-body">
                                                <h5 class="card-title">Luis Bonifácio</h5>
                                                    <p class="card-text">Bom trabalho! </p>
                                                    <p class="card-text"><small class="text-muted">Last update 23 mins ago</small></p>
                                            </div>
                                        </div>
                                </div>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    <!-- FOOTER -->
        <footer>
            <?php include('hfconnectors/footer.php') ?>
        </footer>
    <!-- JAVASCRIPT -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <!-- LOADING SCREEN -->
        <div class="loader"></div>
        <script src="js/loader.js"></script>
</body>
</html>