<?php


    if(isset($_POST['username']) || isset($_POST['email']) || isset($_POST['message'])) {
        if(strlen($_POST['username']) == 0) {
          echo 'Enter your name';
        }
        else if(strlen($_POST['email']) == 0) {
          echo 'Enter your email';
        }
        else if(strlen($_POST['message']) == 0) {
          echo 'Enter your message';
        }
        else {
          $name = $dbconn->real_escape_string($_POST['username']);
          $email = $dbconn->real_escape_string($_POST['email']);
          $message = $dbconn->real_escape_string($_POST['message']);
    
          $sql_coder =  "INSERT INTO messages (username, email, message) VALUES ('$name', '$email', '$message')";
          $sql_query = $dbconn->query($sql_coder) or die();
    
          header("Location: index.php");
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- HEAD -->
    <!-- META -->
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- TITLE -->
        <title>Construction</title>
    <!-- CSS / ICONS -->
        <link rel="shortcut icon" href="img/logo_favicon.png">
        <link rel="stylesheet" href="css/index.css">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/footer.css">
        <link rel="stylesheet" href="css/loader.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
</head>
<body>
    <!-- HEADER -->
        <header>
            <?php include('hfconnectors/header.php') ?>
        </header>
    <!-- MAIN -->
        <main>
        <!-- DIVISION 1 -->
        <div class="d1">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-6 mt-5">
                        <div class="txt-d1-1 mx-5">
                            WE BUILD YOU <br>
                        </div>
                        <div class="txt-d1-2 mx-4">
                            <span class="txt-d1-2-yellow"><b>HOUSE</b></span> OF DREAMS <br>
                        </div>
                        <div class="txt-d1-3 mx-5 mt-4 mb-5">
                            Fast & Safe Construction 
                        </div>
                        <center>
                            <a href="#">
                                <button type="button" class="d1-btn btn btn-warning w-25 mx-5"> <b> GET AN OFFER </b> <i class="bi bi-arrow-right"></i></button>
                            </a>
                        </center>
                    </div>  
                    <div class="col-12 col-md-6 my-5">
                        <center>
                            <img src="img/d1/d1.png" class="img-fluid w-75">
                        </center>
                    </div>
                </div>
            </div>
        </div>
        <!-- DIVISION 2 -->
        <div class="d2">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-8">
                        <div class="txt-d2 my-4">
                            <center>
                                <b> NEED TO CONSULT WITH US? </b>
                            </center>
                        </div>
                    </div>
                    <div class="col-12 col-md-4">
                        <center>
                            <a href="#">
                                <button type="button" class="d2-btn btn btn-dark w-50 my-5"> <b> GET IN TOUCH </b> <i class="bi bi-arrow-right"></i></button>
                            </a>    
                        </center>
                    </div>
                </div>
            </div>
        </div>
        <!-- DIVISION 3 -->
        <div class="d3">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-12">
                        <div class="d3-up-title mt-5">
                            <center>
                                <b> ------------- WHAT WE OFFER ------------- </b>
                            </center>    
                        </div>
                        <div class="d3-title mb-3">
                            <center>
                                <b> WELCOME TO <span class="d3-title-yellow">CONSTRUCTION</span> </b>
                            </center>    
                        </div>
                        <div class="d3-down-title">
                            <center>
                                <b> WE PROVIDE THE BEST SERVICES TO OUR CUSTOMERS </b>
                            </center>    
                        </div>
                    </div>
                </div>
                <div class="row mt-5 mb-5">
                    <div class="col-12 col-md-4 mb-2">
                        <center>
                            <div class="card" style="width: 18rem;">
                                <i class="bi bi-cash-stack my-2"></i>
                                <div class="card-body">
                                    <h5 class="card-title">FAIR PRICE</h5>
                                    <p class="card-text">Fair prices with the best quality, materials and best services.</p>
                                    <a href="#"><p class="card-text"><b>READ MORE <br> <i class="bi bi-arrow-right"></i></b></p></a>
                                </div>
                            </div>
                        </center>
                    </div>
                    <div class="col-12 col-md-4 mb-2">
                        <center>
                            <div class="card" style="width: 18rem;">
                                <i class="bi bi-rocket-takeoff-fill my-2"></i>
                                <div class="card-body">
                                    <h5 class="card-title">24/7 SUPPORT</h5>
                                    <p class="card-text">We provide 24/7 services to our customers.</p>
                                    <a href="#"><p class="card-text"><b>READ MORE <br> <i class="bi bi-arrow-right"></i></b></p></a>
                                </div>
                            </div>    
                        </center>
                    </div>
                    <div class="col-12 col-md-4 mb-2">
                        <center>
                            <div class="card" style="width: 18rem;">
                                <i class="bi bi-stopwatch-fill my-2"></i>
                                <div class="card-body">
                                    <h5 class="card-title">FAST DELIVERY</h5>
                                    <p class="card-text">We offer you the best result in the fastest possible time.</p>
                                    <a href="#"><p class="card-text"><b>READ MORE <br> <i class="bi bi-arrow-right"></i></b></p></a>
                                </div>
                            </div>    
                        </center>
                    </div>
                </div>
            </div>
        </div>
        <!-- DIVISION 4 -->
        <div class="d4">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-12">
                        <div class="rounded my-4">
                            <video src="" class="w-100 d4-video rounded" controls poster="img/d4/thumbnail.png"></video>
                        </div>
                    </div>
                </div>
            </div>          
        </div>
        <!-- DIVISION 5 -->
        <div class="d5">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-12">
                        <div class="d5-up-title mt-5">
                            <center>
                                <b> ------------- WE ARE CAPABLE ------------- </b>
                            </center>
                        </div>
                        <div class="d5-title mb-5">
                            <center>
                                <b> OF <span class="d3-title-yellow">WHAT WE OFFER</span> </b>
                            </center>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-md-3"></div>
                    <div class="col-12 col-md-3">
                        <div class="d5-txt mx-5 mb-5">
                            <div class="my-3">
                                <i class="bi bi-cone-striped mx-2"></i> BETTER <b>ARCHITECTURE</b> <br>
                            </div>
                            <div class="my-3">
                                <i class="bi bi-flower3 mx-2"></i> ECO <b>ENERGY</b> <br>
                            </div>
                            <div class="my-3">
                                <i class="bi bi-truck mx-2"></i> TRANSPORTATION <b>OF CONCRETE</b>
                            </div>
                        </div>
                    </div>      
                    <div class="col-12 col-md-3">
                        <div class="d5-txt mx-5">
                            <div class="my-3">
                                <i class="bi bi-paint-bucket mx-2"></i> TILING & <b>PAINTING</b> <br>
                            </div>
                            <div class="my-3">
                                <i class="bi bi-tools mx-2"></i> <b>PREMIUM</b> SUPPORT <br>
                            </div>
                            <div class="my-3">
                                <i class="bi bi-wrench-adjustable mx-2"></i> <b>    REPAIR</b> SERVICE <br>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-3"></div>
                </div>
            </div>
        </div>
        <!-- DIVISION 6 -->
        <div class="d6">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-12">
                    <div class="d6-up-title mt-5">
                            <center>
                                <b> ------------- OUR DEEDS ------------- </b>
                            </center>    
                        </div>
                        <div class="d6-title mb-3">
                            <center>
                                <b> SEE <span class="d6-title-yellow">OUR COLLECTION</span> OF PROJECTS </b>
                            </center>    
                        </div>
                        <div class="d6-down-title mb-5">
                            <center>
                                <b> Take a look at our company's completed projects </b>
                            </center>    
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-md-3 my-4">
                        <img src="img/d6/d6-img1.png" class="img-fluid rounded">
                    </div>
                    <div class="col-12 col-md-3 my-4">
                        <img src="img/d6/d6-img2.png" class="img-fluid rounded">
                    </div>
                    <div class="col-12 col-md-3 my-4">
                        <img src="img/d6/d6-img3.png" class="img-fluid rounded">    
                    </div>
                    <div class="col-12 col-md-3 my-4">
                        <img src="img/d6/d6-img4.png" class="img-fluid rounded">
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-md-12">
                        <center>
                            <a href="#">
                                <button type="button" class="d2-btn btn btn-warning p-3 my-5"> <b> SEE ALL PROJECTS </b> <i class="bi bi-arrow-right"></i></button>
                            </a>    
                        </center>
                    </div>
                </div>
            </div>
        </div>
        <!-- DIVISION 7-->
        <div class="d7">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-2"></div>
                    <div class="col-12 col-md-2">
                        <div class="d7-txt my-5">
                            <center>
                                <span class="d7-txt-black"><b> 70+ </b></span><br> PROJECTS <br> COMPLETE
                            </center>
                        </div>
                    </div>
                    <div class="col-12 col-md-2">
                        <div class="d7-txt my-5">
                            <center>
                                <span class="d7-txt-black"><b> 100+ </b></span><br> CREATIVE <br> MATERIALS
                            </center>
                        </div>
                    </div>
                    <div class="col-12 col-md-2">
                        <div class="d7-txt my-5">
                            <center>
                                <span class="d7-txt-black"><b> 20+ </b></span><br> EXPERIENCED <br> MASTERS
                            </center>
                        </div>
                    </div>
                    <div class="col-12 col-md-2">
                        <div class="d7-txt my-5">
                            <center>
                                <span class="d7-txt-black"><b> 15+ </b></span><br> PROFESSIONAL <br> BPABEIA
                            </center>
                        </div>
                    </div>
                    <div class="col-12 col-md-2"></div>
                </div>
            </div>
        </div>
        <!-- DIVISION 8 -->
        <div class="d8">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-6 my-3">
                        <img src="img/d8/d8.png" class="w-100 img-fluid">
                    </div>
                    <div class="col-12 col-md-6 my-5">
                        <div class="d8-up-title mx-4">
                            we are everywhere
                        </div>
                        <div class="d8-title mx-4">
                            <b> WE PROVIDE EXTENDED <br>
                            WARRANTIES <span class="d8-title-yellow">FROM LEADING<br>
                            SUPPLIERS IN THE INDUSTRY.</span></b>
                        </div>
                        <a href="aboutus.php">
                            <button type="button" class="d2-btn btn btn-warning p-3 my-5 mx-4"> <b> ABOUT US </b> <i class="bi bi-arrow-right"></i></button>
                        </a> 
                    </div>
                </div>
            </div>
        </div>
        <!-- DIVISION 9 -->
        <div class="d9">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-6 my-5">
                        <center>
                            <div class="d9-up-title">
                                WANT TO BE INFORMED --------------------- <br>
                            </div>
                            <div class="d9-title">
                                <b>SUBSCRIBE TO OUR <span class="d9-title-yellow">NEWSLETTER</span></b> 
                            </div>
                        </center>
                    </div>
                    <div class="col-12 col-md-6 my-5">
                        <center>
                            <br>
                            <form class="d-flex" role="search">
                                <input class="form-control me-2 w-75 p-2" type="search" placeholder="Enter your email">
                                <button class="btn btn-warning" type="submit">SIGN UP</button>
                            </form>  
                        </center>  
                    </div>
                </div>
            </div>
        </div>
        <!-- DIVISION 10 -->
        <div class="d10">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-12">
                        <hr>
                        <center>
                            <div class="d10-up-title mt-5">
                                --------------- WE OFFER ---------------
                            </div>
                            <div class="d10-title">
                                <b>BEST <span class="d10-title-yellow">PAYING PLAN</span></b>
                            </div>
                        </center>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-md-4 my-5">
                        <center>
                            <div class="card" style="width: 18rem;">
                                <div class="card-body">
                                    <h5 class="card-title">STARTER</h5>
                                    <h6 class="card-subtitle mb-2 text-muted">SUITABLE FOR STARTING</h6> <br>
                                    <h4 class="card-title">$199.99</h4> <br>
                                    <p class="card-text">• Construction Consulting</p>
                                    <p class="card-text">• Concrete Construction</p>
                                    <p class="card-text">• Design Construction</p>
                                    <p class="card-text line-through">• 24/7 Customer Support</p>
                                    <p class="card-text line-through">• Home loan assistance</p>
                                    <a href="#">
                                        <button type="button" class="btn btn-warning my-2">SIGN UP</button>
                                    </a>
                                </div>
                            </div>    
                        </center> 
                    </div>
                    <div class="col-12 col-md-4 my-5">
                        <center>
                            <div class="card" style="width: 18rem;">
                                <div class="card-body">
                                    <h5 class="card-title">ADVANCED</h5>
                                    <h6 class="card-subtitle mb-2 text-muted">SUITABLE FOR PROFESSION</h6> <br>
                                    <h4 class="card-title">$299.99</h4> <br>
                                    <p class="card-text">• Construction Consulting</p>
                                    <p class="card-text">• Concrete Construction</p>
                                    <p class="card-text">• Design Construction</p>
                                    <p class="card-text">• 24/7 Customer Support</p>
                                    <p class="card-text line-through">• Home loan assistance</p>
                                    <a href="#">
                                        <button type="button" class="btn btn-warning my-2">SIGN UP</button>
                                    </a>
                                </div>
                            </div>    
                        </center>
                    </div>
                    <div class="col-12 col-md-4 my-5">
                        <center>
                            <div class="card" style="width: 18rem;">
                                <div class="card-body">
                                    <h5 class="card-title">ENTERPRISE</h5>
                                    <h6 class="card-subtitle mb-2 text-muted">SUITABLE FOR COMPANY</h6> <br>
                                    <h4 class="card-title">$499.99</h4> <br>
                                    <p class="card-text">• Construction Consulting</p>
                                    <p class="card-text">• Concrete Construction</p>
                                    <p class="card-text">• Design Construction</p>
                                    <p class="card-text">• 24/7 Customer Support</p>
                                    <p class="card-text">• Home loan assistance</p>
                                    <a href="#">
                                        <button type="button" class="btn btn-warning my-2">SIGN UP</button>
                                    </a>
                                </div>
                            </div>    
                        </center>
                    </div>
                </div>
            </div>
        </div>
        <!-- DIVISION 11 -->
        <div class="d11">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-3"></div>
                    <div class="col-12 col-md-6 my-5">
                        <div class="d11-title mx-2">
                            <b> SEND A <span class="d11-title-yellow">MESSAGE</span></b>
                        </div>
                        <form action="" method="post">
                            <div class="row">
                                <div class="col">
                                    <input type="text" class="form-control mb-3" placeholder="Enter your name" name="username">
                                </div>
                                <div class="col">
                                    <input type="email" class="form-control mb-3" placeholder="Enter your email" name="email">
                                </div>
                            </div>
                            <div class="mb-3">
                                <textarea class="form-control" id="exampleFormControlTextarea1" rows="6" placeholder="Message..." name="message"></textarea>
                            </div>
                                <button class="btn btn-warning p-2" type="submit">Submit</button>
                            </div>
                        </form> 
                    <div class="col-12 col-md-3"></div>
                </div>
                <div class="row">
                    <div class="col-12 col-md-3"></div>
                    <div class="col-12 col-md-6">
                        <div class="row">
                            <div class="col-12 col-md-4 my-5">
                                <center>
                                    <i class="bi bi-geo-alt-fill"></i> <br>
                                    <b>OFFICE ADRESS</b> <br>
                                    Ano Patisia Athens, 144501 
                                </center>
                            </div>
                            <div class="col-12 col-md-4 my-5">
                                <center>
                                    <i class="bi bi-telephone-fill"></i> <br>
                                    <b>TELEPHONE</b> <br>
                                    +210 122 2242
                                </center>
                            </div>
                            <div class="col-12 col-md-4 my-5">
                                <center>
                                    <i class="bi bi-envelope-at-fill"></i> <br>
                                    <b>SEND EMAIL</b> <br>
                                    info@Construction.gr
                                </center>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-3"></div>
                </div>
            </div>
        </div>
        </main>
    <!-- FOOTER -->
        <footer>
            <?php include('hfconnectors/footer.php') ?>
        </footer>
    <!-- JAVASCRIPT -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <!-- LOADING SCREEN -->
        <div class="loader"></div>
        <script src="js/loader.js"></script>
</body>
</html>