<!DOCTYPE html>
<html lang="en">
<head>
<head>
    <!-- HEAD -->
    <!-- META -->
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- TITLE -->
        <title>Construction</title>
    <!-- CSS / ICONS -->
        <link rel="shortcut icon" href="img/logo_favicon.png">
        <link rel="stylesheet" href="../css/style.css">
        <link rel="stylesheet" href="../footer.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
</head>
</head>
<body>
    <footer>
        <div class="container-fluid">
            <div class="row">
            <div class="col-12 col-md-3"></div>
                <div class="col-12 col-md-2">
                    <center>
                        <div class="h4-f1 mt-3">
                            Const<b>ruction</b>
                        </div>
                    </center>
                        <div class="txt-f1 my-4">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto laboriosam, at praesentium vitae modi molestias deserunt ratione facilis id autem repellendus repudiandae. <br><br> Lorem ipsum dolor sit amet consectetur adipisicing elit. Temporibus vel qui eveniet adipisci excepturi eum corrupti sequi omnis.
                        </div>
                </div>
                <div class="col-12 col-md-2">
                    <center>
                        <div class="h4-f2 mt-3">
                            OUR SERVICES
                        </div>
                    </center>
                        <div class="txt-f2 my-4 mx-4">
                            <a href=""><i class="bi bi-caret-right-fill"></i> Eco Energy</a> <br>
                            <a href=""><i class="bi bi-caret-right-fill"></i> Tiles & Painting</a> <br>
                            <a href=""><i class="bi bi-caret-right-fill"></i> Concrete transport</a> <br>
                            <a href=""><i class="bi bi-caret-right-fill"></i> Repair service</a> <br>
                            <a href=""><i class="bi bi-caret-right-fill"></i> Preminum support</a> <br>
                        </div>
                </div>
                <div class="col-12 col-md-2">
                    <center>
                        <div class="h4-f2 mt-3">
                            CONTACT
                        </div>
                    </center>
                        <div class="h4-f1 mt-4">
                            HEAD OFFICE:
                        </div>
                        <div class="txt-f2">
                            28 Ano Patisia, Athens, 144501 
                        </div>
                        <div class="h4-f1 mt-4">
                            PHONE:
                        </div>
                        <div class="txt-f2">
                            +210 1222242
                        </div>
                    <div class="social-media mt-4">
                        <a href="#" class="mx-1">
                            <i class="bi bi-facebook"></i>
                        </a>
                        <a href="#" class="mx-1">
                            <i class="bi bi-twitter"></i>
                        </a>
                        <a href="#" class="mx-1">
                            <i class="bi bi-linkedin"></i>
                        </a>
                    </div>
                </div>
                <div class="col-12 col-md-3"></div>
            </div>
        </div>
    </footer>
</body>
</html>