<!DOCTYPE html>
<html lang="en">
<head>
<head>
    <!-- HEAD -->
    <!-- META -->
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- TITLE -->
        <title>Construction</title>
    <!-- CSS / ICONS -->
        <link rel="shortcut icon" href="img/logo_favicon.png">
        <link rel="stylesheet" href="../css/style.css">
        <link rel="stylesheet" href="../css/header.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
</head>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-dark" data-bs-theme="dark">
  <div class="container-fluid mx-5 my-4">
    <a class="navbar-brand" href="index.php">Const<b>ruction</b> </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-end" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link active" href="aboutus.php">About us</a>
        <a class="nav-link active" href="services.php">Services</a>
        <a class="nav-link active" href="blog.php">Blog</a>
        <a class="nav-link active" href="contact.php">Contact</a>
        <form class="d-flex mx-2 my-1" role="search">
          <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
          <button class="btn btn-outline-warning" type="submit"><i class="bi bi-search"></i></button>
        </form>
      </div>
    </div>
  </div>
</nav>
</body>
</html>