

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- HEAD -->
    <!-- META -->
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- TITLE -->
        <title>About Us | Construction</title>
    <!-- CSS / ICONS -->
        <link rel="shortcut icon" href="img/logo_favicon.png">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/footer.css">
        <link rel="stylesheet" href="css/aboutus.css">
        <link rel="stylesheet" href="css/loader.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
</head>
<body>
    <!-- HEADER -->
        <header>
            <?php include('hfconnectors/header.php') ?>
        </header>
    <!-- MAIN -->
        <main>
        <div class="imgrinc">
            <div class="container">
                <div class="row">
                   <div class="col-12 col-md-12">
                        <h1 class="brand-heading color-yellow text-center">LEARN MORE ABOUT US</h1>
                        <small class="heading heading-solid color-light center-block"></small>
                        <div class="col-12 col-md-12 text-justify">
                        <p class="subtext">
                            With a deep experience and knowledge of the market, we propose to our partners innovative products, services and innovative
                            solutions in the field of building materials and diy, in order to provide the optimization of their spaces and surrounding structures.
                            The success of our customers is the source of our success, and the motivation we need to continue to do more and better.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <h1 class="h1text">OUR THOUGHT</h1>
        <small class="heading-2 heading-solid-2 color-black center-block"></small>
        <div class="container-fluid">
            <center>
            <div class="row">
                <div class="col-12 col-md-6">
                    <div class="card mb-3" style="max-width: 600px;">
                        <div class="row g-1">
                            <div class="col-md-4">
                                <img src="img/aboutus/vision.jpg" class="img-fluid w-100">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <h5 class="titlecolor">VISION</h5>
                                    <p class="card-text">
                                        We are one of the biggest references in the sector of distribution and distribution of
                                        Building Materials in the north of the country,
                                        based on a stable relationship with our partners and customers.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6">
                    <div class="card mb-3" style="max-width: 600px;">
                        <div class="row g-1">
                            <div class="col-md-4">
                                <img src="img/aboutus/mission.jpg" class="img-fluid w-100">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <h5 class="titlecolor">MISSION</h5>
                                    <p class="card-text">
                                    Our mission is to create added value for our customers, satisfy their needs and make them ambassadors
                                        of our brand and our products, consolidating solid, strategic and sustainable partnerships.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-md-6">
                    <div class="card mb-3" style="max-width: 600px;">
                        <div class="row g-1">
                            <div class="col-md-4">
                                <img src="img/aboutus/valores.jpg" class="img-fluid w-100">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <h5 class="titlecolor">VALUE</h5>
                                    <p class="card-text">
                                        - Satisfaction of our customers; <br>
                                        - Honesty and humility; <br>
                                        - Dedication, confidence and professional competence; <br>
                                        - Team work; <br>
                                        - Social responsability.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6">
                    <div class="card mb-3" style="max-width: 600px;">
                        <div class="row g-1">
                            <div class="col-md-4">
                                <img src="img/aboutus/filosofia.jpg" class="img-fluid w-100">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <h5 class="titlecolor">PHYLOSOSHOPY</h5>
                                    <p class="card-text">
                                        We believe that the key to success lies in investing in solid and lasting relationships with our customers and with the community
                                        we form part of, in rigor, transparency and the internal strengthening of our organization.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </center>
        </div>
        </main>
    <!-- FOOTER -->
        <footer>
            <?php include('hfconnectors/footer.php') ?>
        </footer>
    <!-- JAVASCRIPT -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <!-- LOADING SCREEN -->
        <div class="loader"></div>
        <script src="js/loader.js"></script>
</body>
</html>