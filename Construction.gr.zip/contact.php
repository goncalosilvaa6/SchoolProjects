

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- HEAD -->
    <!-- META -->
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- TITLE -->
        <title>Construction</title>
    <!-- CSS / ICONS -->
        <link rel="shortcut icon" href="img/logo_favicon.png">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/footer.css">
        <link rel="stylesheet" href="css/contact.css">
        <link rel="stylesheet" href="css/loader.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
</head>
<body>
    <!-- HEADER -->
        <header>
            <?php include('hfconnectors/header.php') ?>
        </header>
    <!-- MAIN -->
        <main>
            <div class="fundogeral">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12 col-md-1 colunaesquerda bg-black opacity-75">
                        </div>
                        <div class="col-12 col-md-10 colunadomeio opacity-75">
                            <div class="titulo-contact">
                                Contact
                            </div> 
                            <div class="subtitulo-contact mb-4">
                                TALK TO US
                            </div>                
                            <form>
                                <div class="row">
                                    <div class="col-12 col-md-6">
                                        <div class="mb-3">
                                            <label for="exampleInputEmail1" class="form-label"> <span class="nomeformulario" > Name</span> </label>
                                            <input type="name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleInputEmail1" class="form-label"><span class="nomeformulario" > Email</span></label>
                                            <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-6">
                                        <div class="mb-3">
                                            <label for="exampleInputEmail1" class="form-label"> <span class="nomeformulario" > Surname</span> </label>
                                            <input type="name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleInputEmail1" class="form-label"><span class="nomeformulario" >Phone number</span></label>
                                            <input type="name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                        </div>                           
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="exampleFormControlTextarea1" class="form-label"> <span class="nomeformulario">Message</span></label>
                                    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                                </div>
                                <center>
                                    <button type="submit" class="btn btn-warning">Submit</button>
                                </center>
                            </form>  
                            </div>
                            <div class="col-12 col-md-1 colunadireita bg-black opacity-75">
                            </div>
                        </div>
                    </div>
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-12 col-md-1 colunaesquerda bg-black opacity-75">
                            </div>
                            <div class="col-12 col-md-10 colunadomeio opacity-75 ">
                                <hr>
                                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d96075.91199528775!2d-8.568685120708304!3d41.19185726527474!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd246217926096f5%3A0x500ebbde490fa10!2sValongo%2C%20Portugal!5e0!3m2!1spt-PT!2sgr!4v1678445976624!5m2!1spt-PT!2sgr" width="100%" height="350px" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" class="mb-5"></iframe>
                            </div>
                            <div class="col-12 col-md-1 colunadireita bg-black opacity-75">
                            </div>
                        </div>
                    </div>
            </div>  
        </main>
    <!-- FOOTER -->
        <footer>
            <?php include('hfconnectors/footer.php') ?>
        </footer>
    <!-- JAVASCRIPT -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <!-- LOADING SCREEN -->
        <div class="loader"></div>
        <script src="js/loader.js"></script>
</body>
</html>