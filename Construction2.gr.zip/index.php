<?php


    if(isset($_POST['firstName']) || isset($_POST['lastName']) || isset($_POST['email']) || isset($_POST['subject']) || isset($_POST['message'])) {
        if(strlen($_POST['firstName']) == 0) {
          echo 'Enter your first name';
        }
        else if(strlen($_POST['lastName']) == 0) {
          echo 'Enter your last name';
        }
        else if(strlen($_POST['email']) == 0) {
          echo 'Enter your email';
        }
        else if(strlen($_POST['subject']) == 0) {
            echo 'Enter your subject';
        }
        else if(strlen($_POST['message']) == 0) {
            echo 'Enter your message';
        }
        else {
          $firstName = $dbconn->real_escape_string($_POST['firstName']);
          $lastName = $dbconn->real_escape_string($_POST['lastName']);
          $email = $dbconn->real_escape_string($_POST['email']);
          $subject = $dbconn->real_escape_string($_POST['subject']);
          $message = $dbconn->real_escape_string($_POST['message']);
    
          $sql_code =  "INSERT INTO contacts (firstName, lastName, email, contact_subject, contact_message) VALUES ('$firstName', '$lastName', '$email', '$subject', '$message')";
          $sql_query = $dbconn->query($sql_code) or die();
    
          header("Location: index.php");
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- HEAD -->
    <!-- META -->
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- TITLE -->
        <title>Construction</title>
    <!-- CSS / ICONS -->
        <link rel="shortcut icon" href="img/logo_favicon.png">
        <link rel="stylesheet" href="css/index.css">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/header.css">
        <link rel="stylesheet" href="css/footer.css">
        <link rel="stylesheet" href="css/loader.css">
        <link rel="stylesheet" href="css/scroll.css">
        <link rel="stylesheet" href="css/animations.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
</head>
<body>
    <!-- HEADER -->
        <header>
            <?php include('hfconnectors/header.php') ?>
        </header>
    <!-- MAIN -->
        <main>
        <!-- DIVISION 1 -->
            <div class="d1">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12 col-md-12">
                            <center>
                                <div class="d1-txt-img">
                                    <div class="d1-txt mt-5">
                                        LEADERS IN QUALITY <br>
                                        CONSTRUCTION AND <br>
                                        INFRASTRUCTURE
                                    </div>
                                    <br>
                                    <a href="#services">
                                        <b><i class="bi bi-chevron-down"></i></b>
                                    </a>
                                </div>
                            </center>    
                        </div>
                    </div>
                </div>
            </div>
        <!-- DIVISION 2 -->
            <div class="d2">
                <div class="container-fluid reveal" href="#services">
                    <div class="row">
                        <div class="col-12 col-md-12">
                            <div class="d2-title mt-5">
                                <center>
                                    <b>SERVICES</b>
                                    <hr class="hr-title">
                                </center>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 col-md-4 my-5">
                            <div class="card rounded-0 mx-auto float-end" style="width: 18rem;">
                                <img src="img/d2/card1.png" class="img-fluid" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title">Preconstruction <br> Planning</h5>
                                    <p class="card-text my-4">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eaque aliquid quas recusandae corporis, maxime sunt porro voluptatem a.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-4 my-5">
                            <div class="card rounded-0 mx-auto" style="width: 18rem;">
                                <img src="img/d2/card2.png" class="img-fluid" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title">Architectural <br> Modelling</h5>
                                    <p class="card-text my-4">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eaque aliquid quas recusandae corporis, maxime sunt porro voluptatem a.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-4 my-5">
                            <div class="card rounded-0 mx-auto float-start" style="width: 18rem;">
                                <img src="img/d2/card3.png" class="img-fluid" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title">Construction <br> Management</h5>
                                    <p class="card-text my-4">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eaque aliquid quas recusandae corporis, maxime sunt porro voluptatem a.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <!-- DIVISION 3 -->   
            <div class="d3">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12 col-md-6 bg-d31">
                            <div class="d3-title mt-4 reveal">
                                <center>
                                    <b>ABOUT</b>
                                    <hr class="hr-title reveal">
                                </center>
                            </div>
                            <div class="d3-txt float-end mx-5 mb-5 reveal">
                                Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime esse, delectus commodi neque eaque aperiam perspiciatis tempora voluptas cum ipsa vitae distinctio amet perferendis excepturi natus ratione? Ut, aliquam consequuntur. <br><br> Lorem ipsum dolor, sit amet consectetur adipisicing elit. Sunt sapiente saepe, sint sit amet corporis alias distinctio quas nihil consequuntur expedita labore incidunt culpa quo, tempore ipsa quasi voluptate consectetur! <br><br>
                                Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime esse, delectus commodi neque eaque aperiam perspiciatis tempora voluptas cum ipsa vitae distinctio amet perferendis excepturi natus ratione? Ut, aliquam consequuntur. <br><br> Lorem ipsum dolor, sit amet consectetur adipisicing elit. Sunt sapiente saepe, sint sit amet corporis alias distinctio quas nihil consequuntur expedita labore incidunt culpa quo, tempore ipsa quasi voluptate consectetur! 
                            </div>
                        </div>
                        <div class="col-12 col-md-6 bg-d32"></div>
                    </div>    
                </div>       
            </div>
        <!-- DIVISION 4 -->
            <div class="d4">
                <div class="container-fluid reveal">
                    <div class="row">
                        <div class="col-12 col-md-2 my-5"></div>
                        <div class="col-12 col-md-2 my-5">
                            <center>
                                <div class="d4-num">
                                    <b>2035</b>  <br>
                                </div> 
                                <div class="d4-txt">
                                    Year <br> Established
                                </div>
                            </center>           
                        </div>
                        <div class="col-12 col-md-2 my-5">
                            <center>
                                <div class="d4-num">
                                    <b>260</b> <br>
                                </div> 
                                <div class="d4-txt">
                                    Projects <br> Completed
                                </div>
                            </center>
                        </div>
                        <div class="col-12 col-md-2 my-5">
                            <center>
                                <div class="d4-num">
                                    <b>870</b> <br>
                                </div> 
                                <div class="d4-txt">
                                    Contractors <br> Appointed
                                </div>
                            </center>
                        </div>
                        <div class="col-12 col-md-2 my-5">
                            <center>
                                <div class="d4-num">
                                    <b>26</b> <br>
                                </div> 
                                <div class="d4-txt">
                                    Awards <br> Won
                                </div>
                            </center>
                        </div>
                        <div class="col-12 col-md-2 my-5"></div>
                    </div>
                </div>
            </div>
        <!-- DIVISION 5 -->
            <div class="d5">
                <div class="container-fluid reveal">
                    <div class="row">
                        <div class="col-12 col-md-12">
                            <div class="d5-title mt-5">
                                <center>
                                    <b>PROJECTS</b>
                                    <hr class="hr-title">
                                </center>
                            </div>          
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 col-md-3"></div>
                        <div class="col-12 col-md-3 mb-4">
                            <img src="img/d4/img1.jpg" class="img-fluid float-end">
                        </div>
                        <div class="col-12 col-md-3">
                            <img src="img/d4/img2.jpg" class="img-fluid float-start" alt="...">
                        </div>
                        <div class="col-12 col-md-3 mb-4"></div>
                    </div>
                    <div class="row">
                        <div class="col-12 col-md-3"></div>
                        <div class="col-12 col-md-3 mb-4">
                            <img src="img/d4/img3.jpg" class="img-fluid float-end">
                        </div>
                        <div class="col-12 col-md-3 mb-4">
                            <img src="img/d4/img4.jpg" class="img-fluid float-start" alt="...">
                        </div>
                        <div class="col-12 col-md-3"></div>
                    </div>
                </div>
            </div>
        <!-- DIVISION 6 -->
            <div class="d6">
                <div class="container-fluid reveal">
                    <div class="row">
                        <div class="col-12 col-md-12">
                            <div class="d6-title mt-5">
                                <center>
                                    <b>CLIENTS</b>
                                    <hr class="hr-title">
                                </center>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 col-md-1"></div>
                        <div class="col-12 col-md-2">
                            <center>
                                <img src="img/d6/img1.png" class="img-fluid w-75 img-animation">
                            </center>
                        </div>
                        <div class="col-12 col-md-2">
                            <center>
                                <img src="img/d6/img2.png" class="img-fluid w-75 img-animation">
                            </center>
                        </div>
                        <div class="col-12 col-md-2">
                            <center>
                                <img src="img/d6/img3.png" class="img-fluid w-75 img-animation">
                            </center>
                        </div>
                        <div class="col-12 col-md-2">
                            <center>
                                <img src="img/d6/img4.png" class="img-fluid w-75 img-animation">
                            </center>
                        </div>
                        <div class="col-12 col-md-2">
                            <center>
                                <img src="img/d6/img5.png" class="img-fluid w-75 img-animation">
                            </center>  
                        </div>
                        <div class="col-12 col-md-1"></div>
                    </div>
                </div>
            </div>
        <!-- DIVISION 7 -->
            <div class="d7">
                <div class="container-fluid reveal">
                    <div class="row">
                        <div class="col-12 col-md-12">
                            <div class="d7-title mt-5">
                                <center>
                                    <b>CONTACT</b>
                                    <hr class="hr-title">
                                </center>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 col-md-2"></div>
                        <div class="col-12 col-md-8 mt-5">
                            <iframe width="100%" height="400px" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=Terry%20A%20Francois%20blvd+(My%20Business%20Name)&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe>
                        </div>
                        <div class="col-12 col-md-2"></div>
                    </div>
                    <div class="row">
                        <div class="col-12 col-md-2"></div>
                        <div class="col-12 col-md-4 mt-3">
                            <div class="d7-subtitle">
                                <b>Inquiries</b> <br><br>
                            </div>
                            For any inquiries, questions or commendations, please <br> call: 123-456-7890 or fill out the following form
                            <div class="d7-subtitle mt-5">
                                <b>Contact Us</b> <br><br>
                            </div>
                            <form action="" method="POST">
                                <div class="form">
                                    <label class="form-label">First Name</label>
                                    <input type="text" class="form-control rounded-0" name="firstName" required>
                                </div>
                                <div class="form">
                                    <label class="form-label">Last Name</label>
                                    <input type="text" class="form-control rounded-0" name="lastName" required>
                                </div>
                                <div class="form">
                                    <label class="form-label">Email</label>
                                    <input type="email" class="form-control rounded-0" name="email" required>
                                </div>
                                <div class="form">
                                    <label class="form-label">Subject</label>
                                    <input type="text" class="form-control rounded-0" name="subject" required>
                                </div>
                                <div class="form">
                                    <label class="form-label">Message</label>
                                    <textarea class="form-control rounded-0" rows="4" name="message" required></textarea>
                                </div>
                                <button class="btn btn-dark rounded-0 mt-2 w-25 float-end" type="submit">Submit</button>
                            </form>
                        </div>
                        <div class="col-12 col-md-4 mx-5 mt-3">
                            <div class="d7-subtitle">
                                <b>Head Office</b> <br><br>
                            </div>
                            500 Terry Francois Street <br> San Francisco, CA 94158 <br><br>
                            info@mysite.com <br> Tel: 123-456-7890 <br> Fax: 123-456-7890
                            <div class="d7-subtitle mt-5">
                                <b>Employment</b> <br><br>
                            </div>
                            To apply for a job with Constuction, please <br> send a cover letter together with your C.V. <br> to: info@mysite.com
                            <hr class="hr-title mt-5">
                            <div class="d7-subtitle">
                                Get a quote: 123-456-7890
                            </div>
                        </div>
                        <div class="col-12 col-md-2"></div>
                    </div>
                </div>
            </div>
        </main>
    <!-- FOOTER -->
        <footer>
            <?php include('hfconnectors/footer.php') ?>
        </footer>
    <!-- JAVASCRIPT -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <!-- LOADING SCREEN -->
        <div class="loader"></div>
        <script src="js/loader.js"></script>
    <!-- SCROLL ANIMATION-->
        <script src="js/scroll.js"></script>
</body>
</html>