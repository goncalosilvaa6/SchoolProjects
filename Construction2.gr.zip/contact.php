<?php


    if(isset($_POST['firstName']) || isset($_POST['lastName']) || isset($_POST['email']) || isset($_POST['message'])) {
        if(strlen($_POST['firstName']) == 0) {
          echo 'Enter your first name';
        }
        else if(strlen($_POST['lastName']) == 0) {
          echo 'Enter your last name';
        }
        else if(strlen($_POST['email']) == 0) {
          echo 'Enter your email';
        }
        else if(strlen($_POST['message']) == 0) {
            echo 'Enter your message';
        }
        else {
          $firstName = $dbconn->real_escape_string($_POST['firstName']);
          $lastName = $dbconn->real_escape_string($_POST['lastName']);
          $email = $dbconn->real_escape_string($_POST['email']);
          $message = $dbconn->real_escape_string($_POST['message']);
    
          $sql_code =  "INSERT INTO contacts (firstName, lastName, email, contact_message) VALUES ('$firstName', '$lastName', '$email', '$message')";
          $sql_query = $dbconn->query($sql_code) or die();
    
          header("Location: contact.php");
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- HEAD -->
    <!-- META -->
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- TITLE -->
        <title>Contact | Construction</title>
    <!-- CSS / ICONS -->
        <link rel="shortcut icon" href="img/logo_favicon.png">
        <link rel="stylesheet" href="css/index.css">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/header.css">
        <link rel="stylesheet" href="css/footer.css">
        <link rel="stylesheet" href="css/loader.css">
        <link rel="stylesheet" href="css/scroll.css">
        <link rel="stylesheet" href="css/contact.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
</head>
<body>
    <!-- HEADER -->
        <header>
            <?php include('hfconnectors/header.php') ?>
        </header>
    <!-- MAIN -->
        <main>
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-md-4"></div>
                <div class="col-12 col-md-4">
                    <h6 class="h6text">Let's Contact</h6>
                    <h1 class="h1text">Contact</h1>
                    <p class="ptext">
                        This is your Contact section paragraph. Encourage your reader to reach out with any questions,
                        comments or to take a different action specific to your site.
                    </p>
                </div>
                <div class="col-12 col-md-4"></div>
            </div>
        </div>
        <br><br>
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-md-6 border">
                    <div class="row resp1">
                        <div class="col-12 col-sm-6">
                            <i class="bi bi-geo-alt"></i>
                            <br><br>
                            <span class="spantext">Address</span>
                            <br><br>
                            <p>
                                500 Terry Francice St. <br>
                                San Francisco, CA 94158
                            </p>
                        </div>
                        <div class="col-12 col-sm-6">
                            <i class="bi bi-telephone"></i>
                            <br><br>
                            <span class="spantext">Phone</span>
                            <br><br>
                            <p>
                                123-456-7890
                            </p>
                        </div>
                    </div>
                    <div class="row resp2">
                        <div class="col-12 col-sm-6">
                            <i class="bi bi-envelope"></i>
                            <br><br>
                            <span class="spantext">Email</span>
                            <br><br>
                            <p>
                                info@mysite.com
                            </p>
                        </div>
                        <div class="col-12 col-sm-6">
                        <i class="bi bi-hand-thumbs-up"></i>
                            <br><br>
                            <span class="spantext">Social Media</span>
                            <br><br>
                            <p>
                                <a href=""><img src="img/contact/facebook.png"></a>
                                <a href=""><img src="img/contact/twitter.png"></a>
                                <a href=""><img src="img/contact/linkdin.png"></a>
                                <a href=""><img src="img/contact/instagram.png"></a>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 border column">
                    <br><br>
                    <form action="" method="post">
                        <center>
                        <small class="sizes colorsmall">First Name</small>
                        <br>
                        <input class="sizes" type="text" name="firstName">
                        <br><br>
                        <small class="sizes colorsmall">Last Name</small>
                        <br>
                        <input class="sizes" type="text" name="lastName">
                        <br><br>
                        <small class="sizes colorsmall">Email</small>
                        <br>
                        <input class="sizes" type="email" name="email">
                        <br><br>
                        <small class="sizes colorsmall">Message</small>
                        <br>
                        <textarea name="message" cols="50" rows="3"></textarea>
                        <br><br>
                        <button class="sizes buttonsub" type="submit">Send</button>
                        </center>
                    </form>    
                    <br><br>    
                </div>
            </div>
        </div>
        </main>
    <!-- FOOTER -->
        <footer>
            <?php include('hfconnectors/footer.php') ?>
        </footer>
    <!-- JAVASCRIPT -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <!-- LOADING SCREEN -->
        <div class="loader"></div>
        <script src="js/loader.js"></script>
    <!-- SCROLL ANIMATION-->
        <script src="js/scroll.js"></script>
</body>
</html>