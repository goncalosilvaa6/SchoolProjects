<!DOCTYPE html>
<html lang="en">
<head>
<head>
    <!-- HEAD -->
    <!-- META -->
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- TITLE -->
        <title>Construction</title>
    <!-- CSS / ICONS -->
        <link rel="shortcut icon" href="img/logo_favicon.png">
        <link rel="stylesheet" href="../css/style.css">
        <link rel="stylesheet" href="../css/header.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
</head>
</head>
<body>
  <nav class="navbar navbar-expand-lg bg-header" data-bs-theme="dark">
    <div class="container-fluid">
      <a class="navbar-brand p-3" href="index.php">CONSTRUCTION</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" data-bs-theme="dark">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-center" id="navbarNavAltMarkup">
        <div class="navbar-nav">
          <a class="nav-link" href="index.php">HOME</a>
          <a class="nav-link" href="services.php">SERVICES</a>
          <a class="nav-link" href="aboutus.php">ABOUT US</a>
          <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" role="button" data-bs-toggle="dropdown">
            PROJECTS
          </a>
          <ul class="dropdown-menu">
          <li><a class="dropdown-item" href="projects.php">PROJECTS 1</a></li>
            <li><a class="dropdown-item" href="projects2.php">PROJECTS 2</a></li>
            <li><a class="dropdown-item" href="projects3.php">PROJECTS 3</a></li>
            <li><a class="dropdown-item" href="projects4.php">PROJECTS 4</a></li>
          </ul>
        </li>
          <a class="nav-link" href="contact.php">CONTACT</a>
          <a class="nav-link" href="blog.php">BLOG</a>
        </div>
      </div>
    </div>
  </nav>
</body>
</html>