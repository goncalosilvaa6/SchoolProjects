
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- HEAD -->
    <!-- META -->
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- TITLE -->
        <title>Projects | Construction</title>
    <!-- CSS / ICONS -->
        <link rel="shortcut icon" href="img/logo_favicon.png">
        <link rel="stylesheet" href="css/index.css">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/header.css">
        <link rel="stylesheet" href="css/footer.css">
        <link rel="stylesheet" href="css/loader.css">
        <link rel="stylesheet" href="css/scroll.css">
        <link rel="stylesheet" href="css/projects.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
</head>
<body>
    <!-- HEADER -->
        <header>
            <?php include('hfconnectors/header.php') ?>
        </header>
    <!-- MAIN -->
        <main>
        <div class="container-fluid">
                <div class="row bggrey">
                    <div class="col-12 col-md-6">
                        <span class="h1color">PROJECT 3</span>
                        <hr class="hr-sm w-25">
                    </div>
                </div>
                <br><br><br>
                <center>
                <div class="row">
                    <div class="col-12 col-md-6 ">
                        <p>
                            I'm a paragraph. Click here to add your own text and edit me. It’s easy. Just click “Edit Text” or double click me
                            to add your own content and make changes to the font. Feel free to drag and drop me anywhere you like on your page.
                            I’m a great place for you to tell a story and let your users know a little more about you. This is a great space to write
                            long text about your company and your services. You can use this space to go into a little more detail about your company.
                            Talk about your team and what services you provide. Tell your visitors the story of how you came up with the idea
                            for your business and what makes you different from your competitors. Make your company stand out and show your visitors
                            who you are.
                        </p>
                        <br><br><br><br><br>
                        <a href="index.php"><button class="butao" type="submit">BACK TO PROJECTS</button></a>
                        <br><br>
                    </div>
                    <div class="col-12 col-md-6">
                        <img class="img-fluid" src="img/projects/projects1.jpg" alt="">
                    </div>
                </div>
                </center>
            </div>
        </main>
    <!-- FOOTER -->
        <footer>
            <?php include('hfconnectors/footer.php') ?>
        </footer>
    <!-- JAVASCRIPT -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <!-- LOADING SCREEN -->
        <div class="loader"></div>
        <script src="js/loader.js"></script>
    <!-- SCROLL ANIMATION-->
        <script src="js/scroll.js"></script>
</body>
</html>