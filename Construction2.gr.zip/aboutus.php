
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- HEAD -->
    <!-- META -->
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- TITLE -->
        <title>Construction</title>
    <!-- CSS / ICONS -->
        <link rel="shortcut icon" href="img/logo_favicon.png">
        <link rel="stylesheet" href="css/index.css">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/header.css">
        <link rel="stylesheet" href="css/footer.css">
        <link rel="stylesheet" href="css/loader.css">
        <link rel="stylesheet" href="css/aboutus.css">
        <link rel="stylesheet" href="css/scroll.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
</head>
<body>
    <!-- HEADER -->
        <header>
            <?php include('hfconnectors/header.php') ?>
        </header>
    <!-- MAIN -->
        <main>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-3"></div>
                    <div class="col-12 col-md-6">
                        <center>
                            <h1 class="titulo mt-4">About Us</h1>
                            <h5 class="sub-titulo">Finding Inspiration in Every Turn</h5>
                        <br>
                            <p>This is your About Page. This space is a great opportunity to give a full background on who you
                            are, what you do and what your website has to offer. Double click on the text box to start editing your content
                            and make sure to add all the relevant details you want site visitors to know.
                            </p>
                        </center>
                    </div>
                    <div class="col-12 col-md-3"></div>
                </div> 
                <div class="row">
                    <img class="img-fluid w-75" src="img/aboutus/paisagem.jpg" alt="">
                </div>       
            </div>
            <div class="container-fluid reveal">
                <div class="row">
                <div class="col-12 col-md-3"></div>
                    <div class="col-12 col-md-6">
                        <center>
                            <h3 class="titulo mt-5">Our Story</h3>
                            <hr class="hr-sm w-25">
                            <p>
                            Every website has a story, and your visitors want to hear yours.
                            This space is a great opportunity to give a full background on who you 
                            are, what your team does, and what your site has to offer.
                            Double click on the text box to start editing your content and make sure to add all the relevant details
                            you want site visitors to know.
                        <br><br>
                            If you’re a business, talk about how you started and share your professional journey.
                            Explain your core values, your commitment to customers, and how you stand out from the
                            crowd. Add a photo, gallery, or video for even more engagement.
                            </p>
                        </center>
                    </div>
                    <div class="col-12 col-md-3"></div>
                </div>
            </div>
            <div class="container-fluid reveal">
                <div class="row">
                    <div class="col-12 col-md-12">
                        <center>
                        <h3 class="titulo">Meet The Team</h3>
                        <hr class="hr-sm w-25">                            
                        </center>

                    </div>
                </div>
            </div>



  
  
            <div class="container-fluid">
                <div class="row">
                    <div class="col"></div>
                    <div class="col">
                        <img  class="img-fluid w-100 reveal"  src="img/aboutus/pessoa2.jpg" alt="Imagem 1">
                        <p class="reveal">Don Francis</p>
                    </div>
                    <div class="col">
                        <img class="img-fluid w-100 reveal" src="img/aboutus/pessoa1.jpg" alt="Imagem 2">
                        <p class="reveal">Ashley Jones</p>
                    </div>
                    <div class="col"></div>
                </div>
                <div class="row">
                    <div class="col"></div>
                    <div class="col">
                        <img  class="img-fluid w-100 reveal"  src="img/aboutus/pessoa3.jpg" alt="Imagem 1">
                        <p class="">Tess Brown</p>
                    </div>
                    <div class="col">
                        <img class="img-fluid w-100 reveal" src="img/aboutus/pessoa4.jpg" alt="Imagem 2">
                        <p class="">Lisa Rose</p>
                    </div>
                    <div class="col"></div>
                </div>
                <div class="row">
                    <div class="col"></div>
                    <div class="col">
                        <img  class="img-fluid w-100 reveal"  src="img/aboutus/pessoa5.jpg" alt="Imagem 1">
                        <p class="">Alex Young</p>
                    </div>
                    <div class="col">
                        <img class="img-fluid w-100 reveal" src="img/aboutus/pessoa6.jpg" alt="Imagem 2">
                        <p class="">Kevin Nye</p>
                    </div>  
                    <div class="col"></div>
                </div>
            </div>
                
        </main>
    <!-- FOOTER -->
        <footer>
            <?php include('hfconnectors/footer.php') ?>
        </footer>
    <!-- JAVASCRIPT -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <!-- LOADING SCREEN -->
        <div class="loader"></div>
        <script src="js/loader.js"></script>
    <!-- SCROLL ANIMATION-->
        <script src="js/scroll.js"></script>
</body>
</html>