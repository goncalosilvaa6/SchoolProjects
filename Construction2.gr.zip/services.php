<?php


    if(isset($_POST['firstName']) || isset($_POST['lastName']) || isset($_POST['email']) || isset($_POST['message'])) {
        if(strlen($_POST['firstName']) == 0) {
          echo 'Enter your first name';
        }
        else if(strlen($_POST['lastName']) == 0) {
          echo 'Enter your last name';
        }
        else if(strlen($_POST['email']) == 0) {
          echo 'Enter your email';
        }
        else if(strlen($_POST['message']) == 0) {
            echo 'Enter your message';
        }
        else {
          $firstName = $dbconn->real_escape_string($_POST['firstName']);
          $lastName = $dbconn->real_escape_string($_POST['lastName']);
          $email = $dbconn->real_escape_string($_POST['email']);
          $message = $dbconn->real_escape_string($_POST['message']);
    
          $sql_code =  "INSERT INTO contacts (firstName, lastName, email, contact_message) VALUES ('$firstName', '$lastName', '$email', '$message')";
          $sql_query = $dbconn->query($sql_code) or die();
    
          header("Location: services.php");
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- HEAD -->
    <!-- META -->
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- TITLE -->
        <title>Construction</title>
    <!-- CSS / ICONS -->
        <link rel="shortcut icon" href="img/logo_favicon.png">
        <link rel="stylesheet" href="css/index.css">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/header.css">
        <link rel="stylesheet" href="css/footer.css">
        <link rel="stylesheet" href="css/loader.css">
        <link rel="stylesheet" href="css/services.css">
        <link rel="stylesheet" href="css/aboutus.css">
        <link rel="stylesheet" href="css/scroll.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
</head>
<body>
    <!-- HEADER -->
        <header>
            <?php include('hfconnectors/header.php') ?>
        </header>
    <!-- MAIN -->
        <main>
            <div class="container-fluid">
                <div class="row">
                    <img class="img-fluid w-75 mt-5" src="img/services/imagem1.png" alt="">
                </div>       
            </div>

            <div class="container-fluid">
                <div class="row mt-5">
                    <div class="col-12 col-md-4">
                        <center>
                            <h4>Service Name</h4>
                            <p class="texto-1">This is a Paragraph. Click on "Edit Text" or double click on the text box to start editing the content and make sure to add any relevant details or information that you want to share with your visitors.</p class="texto-1">
                        </center>
                    </div>
                    <div class="col-12 col-md-4">
                        <center>
                            <h4>Service Name</h4>
                            <p class="texto-1">This is a Paragraph. Click on "Edit Text" or double click on the text box to start editing the content and make sure to add any relevant details or information that you want to share with your visitors</p class="texto-1">
                        </center>
                    </div>
                    <div class="col-12 col-md-4">
                        <center>
                            <h4>Service Name</h4>
                            <p class="texto-1">This is a Paragraph. Click on "Edit Text" or double click on the text box to start editing the content and make sure to add any relevant details or information that you want to share with your visitors.</p class="texto-1">
                        </center>
                    </div>
                </div>
            </div>
            <div class="container-fluid reveal">
                <div class="row mt-5">
                    <div class="col-12 col-md-4">
                        <center>
                            <h4>Service Name</h4>
                            <p class="texto-1">This is a Paragraph. Click on "Edit Text" or double click on the text box to start editing the content and make sure to add any relevant details or information that you want to share with your visitors.</p class="texto-1">
                        </center>
                    </div>
                    <div class="col-12 col-md-4">
                        <center>
                            <h4>Service Name</h4>
                            <p class="texto-1">This is a Paragraph. Click on "Edit Text" or double click on the text box to start editing the content and make sure to add any relevant details or information that you want to share with your visitors.</p class="texto-1">
                        </center>
                    </div>
                    <div class="col-12 col-md-4">
                        <center>
                            <h4>Service Name</h4>
                            <p class="texto-1">This is a Paragraph. Click on "Edit Text" or double click on the text box to start editing the content and make sure to add any relevant details or information that you want to share with your visitors.</p class="texto-1">
                        </center>
                    </div>
                </div>
            </div>
            <div class="container-fluid reveal">
                <center><h3 class="mt-5 titulooo">Contact</h3></center> 
                <p class="texto-2">Like what you see? Get in touch to learn more.</p>

                <form action="" method="POST">
                    <center>
                    <label for="">First Name</label>
                    <br>
                    <input class="dafa" type="text" id="" name="firstName" required>
                    <br>
                    <label for="">Last Name</label>
                    <br>
                    <input class="dafa" type="text" id="" name="lastName" required>
                    <br>
                    <label for="">Email</label>
                    <br>
                    <input class="dafa" type="email" id="" name="email" required>
                    <br>
                    <label for="">Mensagem</label>
                    <br>
                    <textarea name="message" id="" cols="38" rows="5"></textarea>
                    <br>
                    <br>
                    <input class="buttonsub dafa" type="submit" value="Enviar">
                    </center>
                </form>

            </div>
                
        </main>
    <!-- FOOTER -->
        <footer>
            <?php include('hfconnectors/footer.php') ?>
        </footer>
    <!-- JAVASCRIPT -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <!-- LOADING SCREEN -->
        <div class="loader"></div>
        <script src="js/loader.js"></script>
    <!-- SCROLL ANIMATION-->
        <script src="js/scroll.js"></script>
</body>
</html>