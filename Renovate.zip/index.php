<!DOCTYPE html>
<html lang="en">
<head>
    <!-- HEAD -->
    <!-- META -->
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- TITLE -->
        <title>Renovate</title>
    <!-- CSS / ICONS -->
        <link rel="shortcut icon" href="img/logo_favicon.png">
        <link rel="stylesheet" href="css/index.css">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/header.css">
        <link rel="stylesheet" href="css/footer.css">
        <link rel="stylesheet" href="css/loader.css">
        <link rel="stylesheet" href="css/scroll.css">
        <link rel="stylesheet" href="css/animations.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
</head>
<body>
    <!-- HEADER -->
        <header>
            <div class="container-fluid">
                <div class="row">
                <div class="col-12 col-md-4 my-3">
                    <center>
                    <a href="#">
                        <img src="img/header/renovate-logo.png" class="img-fluid">
                    </a>
                    </center>
                </div>
                <div class="col-12 col-md-4 my-4">
                    <center>
                    <div class="header-call">
                        Make a call: +1 (212) 255-5511
                    </div>
                    </center>
                </div>
                <div class="col-12 col-md-4 my-3">
                    <center>
                    <div class="header-social">
                        <a href="#"><i class="bi bi-facebook"></i></a>
                        <a href="#"><i class="bi bi-twitter"></i></a>
                        <a href="#"><i class="bi bi-instagram"></i></a>
                        <a href="#"><i class="bi bi-linkedin"></i></a>
                    </div> 
                    </center>
                </div>
                </div>
            </div>
            <hr class="header-hr">
            <nav>
                <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-1"></div>
                    <div class="col-12 col-md-5">
                    <div class="row">
                        <div class="col-12 col-md-2">
                        <div class="nav-button">
                            <a href="index.php">
                            Home
                            </a>
                        </div>
                        </div>
                        <div class="col-12 col-md-2">
                        <div class="nav-button">
                            <a href="projects.php">
                            Projects
                            </a>
                        </div>
                        </div>
                        <div class="col-12 col-md-2">
                        <div class="nav-button">
                            <a href="services.php">
                            Services
                            </a>
                        </div>
                        </div>
                        <div class="col-12 col-md-2">
                        <div class="nav-button">
                            <a href="about.php">
                            About
                            </a>
                        </div>
                        </div>
                        <div class="col-12 col-md-2">
                        <div class="nav-button">
                            <a href="contacts.php">
                            Contact us
                            </a>
                        </div>
                        </div>
                        <div class="col-12 col-md-2"></div>
                    </div>
                    </div>
                    <div class="col-12 col-md-5">
                    <div class="header-quote float-end p-2 w-25">
                        <center>
                        <a href="#">
                            GET A QUOTE
                        </a>
                        </center>  
                    </div>
                    </div>
                    <div class="col-12 col-md-1"></div>
                </div>
                </div>
            </nav>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-1"></div>
                    <div class="col-12 col-md-10">
                        <div class="margin-top-title">
                            <div class="header-sub-title">
                                <b>Build Your Dream</b>
                            </div>
                            <div class="header-title">
                                <b>VISION GOT LARGER</b>
                            </div>
                            <div class="header-text">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla porttitor accumsan tincidunt. Donec rutrum <br> congue leo eget malesuada. Nulla porttitor accumsan tincidunt. Donec rutrum congue leo eget malesuada. <br> Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem.
                            </div>
                        </div> 
                    </div>
                    <div class="col-12 col-md-1"></div>
                </div>
                <div class="row">
                    <div class="col-12 col-md-1 mt-4 margin-header"></div>
                    <div class="col-12 col-md-2 mt-4 margin-header">
                        <div class="header-ourservices p-2 w-75">
                            <a href="services.php">
                                <center>
                                    OUR SERVICES
                                </center>
                            </a> 
                        </div>
                    </div>
                    <div class="col-12 col-md-2 mt-4 margin-header">
                        <div class="header-contactus p-2 w-75">
                            <a href="contactus.php">
                                <center>
                                    CONTACT US
                                </center>
                            </a>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 mt-4 margin-header"></div>
                    <div class="col-12 col-md-1 mt-4 margin-header"></div>
                </div>
            </div>
        </header>
    <!-- MAIN -->
        <main> 
        <!-- DIVISION 1  -->
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-1"></div>
                    <div class="col-12 col-md-10 shadow-lg rounded-0 my-4">
                        <div class="row">
                            <div class="col-12 col-md-6 bg-div1">
                                <div class="sub-title-div1 mt-5 mx-4">
                                    <b>Build Your Dream</b> 
                                </div>
                                <div class="title-div1 mx-4">
                                    <b>25 Years Of Undefeated Success</b> 
                                </div>
                                <div class="text-div1 mx-4 mt-2 mb-5">
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque in <br> ipsum id orci porta dapibus. Vivamus magna justo, lacinia eget <br> consectetur sed, convallis .
                                </div>
                                <div class="workwithus-div1 mx-4 mb-5 p-2 w-25">
                                    <a href="" class="workwithus-div1">
                                        <center>
                                            WORK WITH US
                                        </center>
                                    </a>    
                                </div>
                            </div>
                            <div class="col-12 col-md-6">
                                <div class="row">
                                    <div class="col-12 col-md-6 mt-5">
                                        <div class="title-div1 mx-5">
                                            <b>512+</b> 
                                        </div>
                                        <div class="text-div1 mx-5">
                                            Successfully Project <br> Finished.
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-6 mt-5">
                                        <div class="title-div1 mx-5">
                                            <b>25+</b> 
                                        </div>
                                        <div class="text-div1 mx-5">
                                            Years of experience with <br> proud
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12 col-md-6 mt-5">
                                        <div class="title-div1 mx-5">
                                            <b>1120+</b>
                                        </div>
                                        <div class="text-div1 mx-5">
                                            Revenue in 2017 investment
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-6 mt-5">
                                        <div class="title-div1 mx-5">
                                            <b>1520+</b>
                                        </div>
                                        <div class="text-div1 mx-5">
                                            Colleagues & counting more <br> daily
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-1"></div>
                </div>
            </div>
        <!-- DIVISION 2 -->
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-1"></div>
                    <div class="col-12 col-md-10 mt-5">
                        <div class="row">
                            <div class="col-12 col-md-12">
                                <div class="sub-title-div2">
                                    <b>Build Your Dream</b> 
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12 col-md-6">
                                <div class="title-div2 mx-1">
                                    <b>Quality Services</b>
                                </div>
                            </div>
                            <div class="col-12 col-md-6">
                                <div class="button-div2 float-end mx-1 mt-4">
                                    <a href="services.php">
                                        VIEW ALL <i class="bi bi-arrow-right"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-1"></div>
                </div>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-1"></div>
                    <div class="col-12 col-md-10">
                        <div class="row">
                            <div class="col-12 col-md-4">
                                <center>
                                    <div class="card border-0 rounded-0 mb-5" style="width: 23rem;">
                                        <img src="img/index/div2/service-1.jpg" class="img-fluid">
                                        <div class="card-body">
                                            <h3 class="card-title text-start"><b>Land Minning</b></h3>
                                            <p class="card-text text-start">Lorem ipsum dolor sit amet, consectetur <br> adipiscing elit. Pellentesque in ipsum.</p>
                                        </div>
                                    </div>    
                                </center>
                            </div>
                            <div class="col-12 col-md-4">
                                <center>
                                    <div class="card border-0 rounded-0 mb-5" style="width: 23rem;">
                                        <img src="img/index/div2/service-2.jpg" class="img-fluid">
                                        <div class="card-body">
                                            <h3 class="card-title text-start"><b>Building Staffs</b></h3>
                                            <p class="card-text text-start">Lorem ipsum dolor sit amet, consectetur <br> adipiscing elit. Pellentesque in ipsum.</p>
                                        </div>
                                    </div>    
                                </center>      
                            </div>
                            <div class="col-12 col-md-4">
                                <center>
                                    <div class="card border-0 rounded-0 mb-5" style="width: 23rem;">
                                        <img src="img/index/div2/service-3.jpg" class="img-fluid">
                                        <div class="card-body">
                                            <h3 class="card-title text-start"><b>Material Supply</b></h3>
                                            <p class="card-text text-start">Lorem ipsum dolor sit amet, consectetur <br> adipiscing elit. Pellentesque in ipsum.</p>
                                        </div>
                                    </div>    
                                </center>             
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12 col-md-4">
                                <center>
                                    <div class="card border-0 rounded-0 mb-5" style="width: 23rem;">
                                        <img src="img/index/div2/services-4.jpg" class="img-fluid">
                                        <div class="card-body">
                                            <h3 class="card-title text-start"><b>Conslutancy</b></h3>
                                            <p class="card-text text-start">Lorem ipsum dolor sit amet, consectetur <br> adipiscing elit. Pellentesque in ipsum.</p>
                                        </div>
                                    </div>    
                                </center>
                            </div>
                            <div class="col-12 col-md-4">
                                <center>
                                    <div class="card border-0 rounded-0 mb-5" style="width: 23rem;">
                                        <img src="img/index/div2/services-5.jpg" class="img-fluid">
                                        <div class="card-body">
                                            <h3 class="card-title text-start"><b>Architecture</b></h3>
                                            <p class="card-text text-start">Lorem ipsum dolor sit amet, consectetur <br> adipiscing elit. Pellentesque in ipsum.</p>
                                        </div>
                                    </div>    
                                </center>      
                            </div>
                            <div class="col-12 col-md-4">
                                <center>
                                    <div class="card border-0 rounded-0 mb-5" style="width: 23rem;">
                                        <img src="img/index/div2/services-6.jpg" class="img-fluid">
                                        <div class="card-body">
                                            <h3 class="card-title text-start"><b>Crane Service</b></h3>
                                            <p class="card-text text-start">Lorem ipsum dolor sit amet, consectetur <br> adipiscing elit. Pellentesque in ipsum.</p>
                                        </div>
                                    </div>    
                                </center>             
                            </div>
                        </div>                    
                    </div>
                    <div class="col-12 col-md-1"></div>
                </div>
            </div>
        <!-- DIVISION 3 -->
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-6 bg1-div3">
                        <div class="mar-bg-div3">
                            <div class="sub-title-div3 mx-5">
                                <b>Sustainability</b> 
                            </div>
                            <div class="title-div3 mx-5">
                                <b>Committed To Keep <br> People Healthy & Safe</b> 
                            </div>
                            <div class="text-div3 mx-5 my-3">
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque<br> in  ipsum id orci porta dapibus.
                            </div>
                            <div class="getatouch-div3 p-2 w-25 mx-5 my-5">
                                <a href="services.php">
                                    <center>
                                        GET A TOUCH
                                    </center>
                                </a> 
                            </div>    
                        </div>
                    </div>
                    <div class="col-12 col-md-6 bg2-div3">
                        <div class="mar-bg-div3">
                            <div class="mini-title-div3 mx-5">
                                <b>We Follow Best Practices</b> 
                            </div>
                            <div class="text-2-div3 mx-5 my-3">
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque<br> in  ipsum id orci porta dapibus.
                            </div>
                            <div class="mini-table mx-5">
                                <div class="my-3">
                                    <b><i class="bi bi-recycle"></i> Sustainablility <br></b> 
                                </div>
                                <div class="my-3">
                                    <b><i class="bi bi-clock-fill"></i> Project On Time <br></b> 
                                </div>
                                <div class="my-3">
                                    <b><i class="bi bi-display"></i> Modern Technology <br></b>
                                </div>
                                <div class="my-3">
                                    <b><i class="bi bi-pencil-fill"></i> Latest Designs</b> 
                                </div>
                            </div>   
                        </div>
                    </div>
                </div>
            </div>
        <!-- DIVISION 4 -->
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-1"></div>
                    <div class="col-12 col-md-5">
                        <div class="sub-title-div4 mt-5 mx-5">
                            <b>Sustainability</b> 
                        </div>
                        <div class="title-div4 mx-5">
                            <b>Transform Communities <br> Across the Globe</b> 
                        </div>
                    </div>
                    <div class="col-12 col-md-5">
                        <div class="text-div4">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque in ipsum id orci porta dapibus. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.
                        </div>
                    </div>
                    <div class="col-12 col-md-1"></div>
                </div>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-1 my-5"></div>
                    <div class="col-12 col-md-10 my-5">
                        <div class="row">
                            <div class="col-12 col-md-4">
                                <div class="card rounded-0 mb-2 mx-auto float-end" style="width: 23rem;">
                                    <div class="card-body">
                                        <h5 class="card-title mx-4 mt-4"><b>CANADA</b></h5>
                                        <p class="card-text mx-4 mb-5">4446 Noble Rd, Cortes Island</p>
                                        <a href="#" class="mx-4 mb-4">DIRECTION <i class="bi bi-arrow-right"></i></a> <br><br>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-md-4">
                                <div class="card rounded-0 mb-2 mx-auto" style="width: 23rem;">
                                    <div class="card-body">
                                        <h5 class="card-title mx-4 mt-4"><b>UNITED STATES</b></h5>
                                        <p class="card-text mx-4 mb-5">2367 Speers Road, Brampton</p>
                                        <a href="#" class="mx-4 mb-4">DIRECTION <i class="bi bi-arrow-right"></i></a> <br><br>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-md-4">
                                <div class="card rounded-0 mb-2 mx-auto float-start" style="width: 23rem;">
                                    <div class="card-body">
                                        <h5 class="card-title mx-4 mt-4"><b>AUSTRALIA</b></h5>
                                        <p class="card-text mx-4 mb-5">4446 Noble Rd, Cortes Island</p>
                                        <a href="#" class="mx-4 mb-4">DIRECTION <i class="bi bi-arrow-right"></i></a> <br><br>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-1 my-5"></div>
                </div>
                <div class="row">
                    <div class="col-12 col-md-12">
                        <div class="viewouroffices-div3 p-2 w-25 mx-auto my-5">
                            <a href="services.php">
                                <center>
                                    VIEW OUR OFFICES
                                </center>
                            </a> 
                        </div>
                    </div>
                </div>
            </div>
        <!-- DIVISION 5 -->
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-12">
                        <div class="sub-title-div5 mt-5 text-center">
                            <b>About Founders</b> 
                        </div>
                        <div class="title-div5 mb-5 text-center">
                            <b>We Are Leading International <br> Company In The World</b> 
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-1"></div>
                    <div class="col-12 col-md-10">
                        <div class="row">
                            <div class="col-12 col-md-4">
                                <center>
                                    <img src="img/index/div5/person1.png" class="img-fluid">
                                </center>
                            </div>
                            <div class="col-12 col-md-4">
                                <center>
                                    <img src="img/index/div5/person2.png" class="img-fluid">
                                </center>
                            </div>
                            <div class="col-12 col-md-4">
                                <center>
                                    <img src="img/index/div5/person3.png" class="img-fluid">
                                </center>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-1"></div>
                </div>
                <div class="row">
                    <div class="col-12 col-md-12">
                        <div class="aboutus-div5 p-2 w-25 mx-auto my-5">
                            <a href="services.php">
                                <center>
                                    VIEW OUR OFFICES
                                </center>
                            </a> 
                        </div>
                    </div>
                </div>
            </div>
        <!-- DIVISION 6 -->
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-1"></div>
                    <div class="col-12 col-md-5">
                        <div class="sub-title-div6">
                            <b>About Founders</b> 
                        </div>
                        <div class="title-div6">
                            <b>Our Latest Works</b> 
                        </div>
                    </div>
                    <div class="col-12 col-md-5">
                        <div class="viewprojects-div6 p-2 w-25 mx-auto float-end my-5">
                            <a href="projects.php">
                                <center>
                                    VIEW PROJECTS
                                </center>
                            </a> 
                        </div>
                    </div>
                    <div class="col-12 col-md-1"></div>
                </div>
            </div>
            <div class="container-fluid my-5">
                <div class="row">
                    <div class="col-12 col-md-3">
                        <img src="img/index/div6/img1.png" class="img-fluid">
                    </div>
                    <div class="col-12 col-md-3">
                        <img src="img/index/div6/img2.png" class="img-fluid">
                    </div>
                    <div class="col-12 col-md-3">
                        <img src="img/index/div6/img3.png" class="img-fluid">
                    </div>
                    <div class="col-12 col-md-3">
                        <img src="img/index/div6/img4.png" class="img-fluid">
                    </div>
                </div>
            </div>
        <!-- DIVISION 7 -->
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-12 my-5">
                        <center>
                            <div class="sub-title-div7">
                                <b>What Our Clients Say</b> 
                            </div>
                            <div class="title-div7">
                                <b>Testimonials</b> 
                            </div>    
                        </center>                
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-1"></div>
                    <div class="col-12 col-md-5">
                        <div class="card-bg mx-auto p-5 mb-4" style="width: 37rem;">
                            <img src="img/index/div7/person1.png" class="card-img-top w-25 rounded-circle">
                            <div class="card-body">
                                <h6 class="card-title text-warning mt-3"><b>Engineering Manager</b></h6>
                                <h5 class="card-title text-white mt-2 mb-3"><b>Alice Howard</b></h5>
                                <p class="card-text text-white">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-5">
                        <div class="card-bg mx-auto p-5 mb-4" style="width: 37rem;">
                            <img src="img/index/div7/person3.png" class="card-img-top w-25 rounded-circle">
                            <div class="card-body">
                                <h6 class="card-title text-warning mt-3"><b>Interior Designer</b></h6>
                                <h5 class="card-title text-white mt-2 mb-3"><b>Nathan Marshall</b></h5>
                                <p class="card-text text-white">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-1"></div>
                </div>
                <div class="row">
                    <div class="col-12 col-md-1"></div>
                    <div class="col-12 col-md-5">
                        <div class="card-bg mx-auto p-5 mb-5" style="width: 37rem;">
                            <img src="img/index/div7/person2.png" class="card-img-top w-25 rounded-circle">
                            <div class="card-body">
                                <h6 class="card-title text-warning mt-3"><b>Architect</b></h6>
                                <h5 class="card-title text-white mt-2 mb-3"><b>Ema Romero</b></h5>
                                <p class="card-text text-white">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-5">
                        <div class="card-bg mx-auto p-5 mb-5" style="width: 37rem;">
                            <img src="img/index/div7/person4.png" class="card-img-top w-25 rounded-circle">
                            <div class="card-body">
                                <h6 class="card-title text-warning mt-3"><b>Manager</b></h6>
                                <h5 class="card-title text-white mt-2 mb-3"><b>Ann Smith</b></h5>
                                <p class="card-text text-white">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-1"></div>
                </div>
            </div>
        <!-- DIVISION 8 -->
            <div class="bg-div8">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12 col-md-1"></div>
                        <div class="col-12 col-md-5">
                            <div class="contact-div8 my-5">
                                <div class="raq-div8 mx-5 mt-4">
                                    <b>Request a Quote</b>
                                </div> 
                                <div class="raq-sub-div8 mx-5 mt-1 mb-2">
                                    Ready to Work Together? Build a project with us!
                                </div>
                                <form action="" method="post">
                                    <input type="text" class="form-control rounded-0 p-2 mx-5 my-4 w-75" placeholder="Enter your name" required name="yourname">
                                    <input type="email" class="form-control rounded-0 p-2 mx-5 my-4 w-75" placeholder="Enter your email address" required name="email">
                                    <input type="text" class="form-control rounded-0 p-2 mx-5 my-4 w-75" placeholder="Enter your name" required name="submessage">
                                    <textarea class="form-control rounded-0 p-2 mx-5 my-4 w-75" placeholder="Message..." rows="4"></textarea>
                                    <button class="btn btn-warning rounded-0 p-2 mx-5 mb-4 w-25" type="submit">Send a Message</button>
                                </form>
                            </div>
                        </div>
                        <div class="col-12 col-md-5">
                            <div class="sub-title-div8 mx-5 mar-div8">
                                <b>Learn More From</b> 
                            </div>
                            <div class="title-div8 mx-5">
                                <b>Frequently Asked Questions</b> 
                            </div>
                            <div class="accordion mx-5 my-4" id="umacordiao">
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne">
                                        1. How to create cities and communites that solve?
                                    </button>
                                    </h2>
                                    <div id="collapseOne" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo">
                                        2. Construction of the winning $45 milion?
                                    </button>
                                    </h2>
                                    <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree">
                                        3. How to create cities and communites that solve?
                                    </button>
                                    </h2>
                                    <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-1"></div>
                    </div>
                </div>
            </div>
        </main>
    <!-- FOOTER -->
        <footer>
            <?php include('hfconnectors/footer.php') ?>
        </footer>
    <!-- JAVASCRIPT -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <!-- LOADING SCREEN -->
        <div class="loader"></div>
        <script src="js/loader.js"></script>
    <!-- SCROLL ANIMATION-->
        <script src="js/scroll.js"></script>
</body>
</html>