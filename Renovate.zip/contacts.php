
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- HEAD -->
    <!-- META -->
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- TITLE -->
        <title>Renovate</title>
    <!-- CSS / ICONS -->
        <link rel="shortcut icon" href="img/logo_favicon.png">
        <link rel="stylesheet" href="css/index.css">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/contactus.css">
        <link rel="stylesheet" href="css/header.css">
        <link rel="stylesheet" href="css/footer.css">
        <link rel="stylesheet" href="css/loader.css">
        <link rel="stylesheet" href="css/scroll.css">
        <link rel="stylesheet" href="css/animations.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
</head>
<body>
    <!-- HEADER -->
        <header>
            <div class="container-fluid">
                <div class="row">
                <div class="col-12 col-md-4 my-3">
                    <center>
                    <a href="#">
                        <img src="img/header/renovate-logo.png" class="img-fluid">
                    </a>
                    </center>
                </div>
                <div class="col-12 col-md-4 my-4">
                    <center>
                    <div class="header-call">
                        Make a call: +1 (212) 255-5511
                    </div>
                    </center>
                </div>
                <div class="col-12 col-md-4 my-3">
                    <center>
                    <div class="header-social">
                        <a href="#"><i class="bi bi-facebook"></i></a>
                        <a href="#"><i class="bi bi-twitter"></i></a>
                        <a href="#"><i class="bi bi-instagram"></i></a>
                        <a href="#"><i class="bi bi-linkedin"></i></a>
                    </div> 
                    </center>
                </div>
                </div>
            </div>
            <hr class="header-hr">
            <nav>
                <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-1"></div>
                    <div class="col-12 col-md-5">
                    <div class="row">
                        <div class="col-12 col-md-2">
                        <div class="nav-button">
                            <a href="index.php">
                            Home
                            </a>
                        </div>
                        </div>
                        <div class="col-12 col-md-2">
                        <div class="nav-button">
                            <a href="projects.php">
                            Projects
                            </a>
                        </div>
                        </div>
                        <div class="col-12 col-md-2">
                        <div class="nav-button">
                            <a href="services.php">
                            Services
                            </a>
                        </div>
                        </div>
                        <div class="col-12 col-md-2">
                        <div class="nav-button">
                            <a href="about.php">
                            About
                            </a>
                        </div>
                        </div>
                        <div class="col-12 col-md-2">
                        <div class="nav-button">
                            <a href="contacts.php">
                            Contact us
                            </a>
                        </div>
                        </div>
                        <div class="col-12 col-md-2"></div>
                    </div>
                    </div>
                    <div class="col-12 col-md-5">
                    <div class="header-quote float-end p-2 w-25">
                        <center>
                        <a href="#">
                            GET A QUOTE
                        </a>
                        </center>  
                    </div>
                    </div>
                    <div class="col-12 col-md-1"></div>
                </div>
                </div>
            </nav>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-1"></div>
                    <div class="col-12 col-md-10">
                        <div class="margin-top-title mb-5">
                            <div class="header-title-categories">
                                <center>
                                    <b>CONTACT US</b>
                                </center>
                            </div>
                        </div> 
                    </div>
                    <div class="col-12 col-md-1"></div>
                </div>
            </div>
        </header>
    <!-- MAIN -->
        <main>    
            <div class="container-fluid my-5">
                <center>
                    <div class="sub-title1">
                        <h3>Our Branches</h5>    
                    </div>
                        <div class="title">
                            <h1>Contact Details</h3>      
                        </div>            
                </center>
            </div>
            <div class="container-fluid">
                <div class="row my-5">
                    <div class="col-12 col-md-4">
                        <div class="texto-geral">
                            <div class="titulos">
                                Canada Head Office
                                <br>
                                Address:
                            </div>
                                <div class="sub-title">
                                    75 Tower Court Kernersville, NC 27284 PO Box
                                    <br>
                                    6658 Rockhild SDT 2505
                                    <br>
                                    <br>                                
                                </div>
                            <div class="titulos">
                                Phone:
                            </div>
                                <div class="sub-title">
                                    +1 (238) 456 7894
                                    <br>
                                    <br>
                                </div>
                            <div class="titulos">
                                Email:
                            </div>
                                <div class="sub-title">
                                    contact@example.com
                                    support@example.com                          
                                </div>
                                <br>
                            <center>
                                <button class="sizes buttonsub" type="submit">GET APPOINTMENT</button>
                            </center> 
                        </div>
                    </div>
                    <div class="col-12 col-md-8">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2886.7266602158847!2d-79.38313500000001!3d43.653855!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89d4cb90d7c63ba5%3A0x323555502ab4c477!2zVG9yb250bywgT04sIENhbmFkw6E!5e0!3m2!1spt-PT!2sus!4v1679663883886!5m2!1spt-PT!2sus" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </div>
            </div>
            <br>
            <div class="container-fluid">
                <div class="row my-5">
                    <div class="col-12 col-md-8">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2886.7266602158847!2d-79.38313500000001!3d43.653855!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89d4cb90d7c63ba5%3A0x323555502ab4c477!2zVG9yb250bywgT04sIENhbmFkw6E!5e0!3m2!1spt-PT!2sus!4v1679663883886!5m2!1spt-PT!2sus" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                    <div class="col-12 col-md-4">
                        <div class="texto-geral">
                            <div class="titulos">
                                Canada Head Office
                                <br>
                                Address:
                            </div>
                                <div class="sub-title">
                                    75 Tower Court Kernersville, NC 27284 PO Box
                                    <br>
                                    6658 Rockhild SDT 2505
                                    <br>
                                    <br>                                
                                </div>
                            <div class="titulos">
                                Phone:
                            </div>
                                <div class="sub-title">
                                    +1 (238) 456 7894      
                                    <br>
                                    <br>
                                </div>
                            <div class="titulos">
                                Email:
                            </div>
                                <div class="sub-title">
                                    contact@example.com
                                    support@example.com                             
                                </div>
                                <br>
                            <center>
                                <button class="sizes buttonsub" type="submit">GET APPOINTMENT</button>
                            </center> 
                        </div>                    
                    </div>
            </div>
        </main>
    <!-- FOOTER -->
        <footer>
            <?php include('hfconnectors/footer.php') ?>
        </footer>
    <!-- JAVASCRIPT -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <!-- LOADING SCREEN -->
        <div class="loader"></div>
        <script src="js/loader.js"></script>
    <!-- SCROLL ANIMATION-->
        <script src="js/scroll.js"></script>
</body>
</html>