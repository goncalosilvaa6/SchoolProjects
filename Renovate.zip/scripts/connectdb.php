<?php 
    $server = 'localhost';
    $username = 'root';
    $password = '';
    $db = 'renovate';

    $dbconn = new mysqli($server, $username, $password, $db);

    if ($dbconn->connect_error) {
        die("connection failed: " .$dbcon->connct_error);
    }
?>