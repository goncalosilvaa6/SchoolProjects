
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- HEAD -->
    <!-- META -->
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- TITLE -->
        <title>Renovate</title>
    <!-- CSS / ICONS -->
        <link rel="shortcut icon" href="img/logo_favicon.png">
        <link rel="stylesheet" href="css/index.css">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/header.css">
        <link rel="stylesheet" href="css/footer.css">
        <link rel="stylesheet" href="css/loader.css">
        <link rel="stylesheet" href="css/scroll.css">
        <link rel="stylesheet" href="css/animations.css">
        <link rel="stylesheet" href="css/about.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
</head>
<body>
    <!-- HEADER -->
        <header>
            <div class="container-fluid">
                <div class="row">
                <div class="col-12 col-md-4 my-3">
                    <center>
                    <a href="#">
                        <img src="img/header/renovate-logo.png" class="img-fluid">
                    </a>
                    </center>
                </div>
                <div class="col-12 col-md-4 my-4">
                    <center>
                    <div class="header-call">
                        Make a call: +1 (212) 255-5511
                    </div>
                    </center>
                </div>
                <div class="col-12 col-md-4 my-3">
                    <center>
                    <div class="header-social">
                        <a href="#"><i class="bi bi-facebook"></i></a>
                        <a href="#"><i class="bi bi-twitter"></i></a>
                        <a href="#"><i class="bi bi-instagram"></i></a>
                        <a href="#"><i class="bi bi-linkedin"></i></a>
                    </div> 
                    </center>
                </div>
                </div>
            </div>
            <hr class="header-hr">
            <nav>
                <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-1"></div>
                    <div class="col-12 col-md-5">
                    <div class="row">
                        <div class="col-12 col-md-2">
                        <div class="nav-button">
                            <a href="index.php">
                            Home
                            </a>
                        </div>
                        </div>
                        <div class="col-12 col-md-2">
                        <div class="nav-button">
                            <a href="projects.php">
                            Projects
                            </a>
                        </div>
                        </div>
                        <div class="col-12 col-md-2">
                        <div class="nav-button">
                            <a href="services.php">
                            Services
                            </a>
                        </div>
                        </div>
                        <div class="col-12 col-md-2">
                        <div class="nav-button">
                            <a href="about.php">
                            About
                            </a>
                        </div>
                        </div>
                        <div class="col-12 col-md-2">
                        <div class="nav-button">
                            <a href="contacts.php">
                            Contact us
                            </a>
                        </div>
                        </div>
                        <div class="col-12 col-md-2"></div>
                    </div>
                    </div>
                    <div class="col-12 col-md-5">
                    <div class="header-quote float-end p-2 w-25">
                        <center>
                        <a href="#">
                            GET A QUOTE
                        </a>
                        </center>  
                    </div>
                    </div>
                    <div class="col-12 col-md-1"></div>
                </div>
                </div>
            </nav>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-1"></div>
                    <div class="col-12 col-md-10">
                        <div class="margin-top-title mb-5">
                            <div class="header-title-categories">
                                <center>
                                    <b>ABOUT US</b>
                                </center>
                            </div>
                        </div> 
                    </div>
                    <div class="col-12 col-md-1"></div>
                </div>
            </div>
        </header>
    <!-- MAIN -->
        <main>
            <div class="container-fluid topmargin-div1">
                <div class="row mx-3">
                    <div class="col-12 col-md-6">
                        <h4 class="colortitle">About Us</h4>
                        <h1 class="colortitle2">We Are Leading International Company In The World</h1>
                        <div>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.
                            <br><br>
                            Cras ultricies ligula sed magna dictum porta. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                            Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem.
                        </div>
                        <div class="our-services p-2 w-25">
                            <center>
                            <a href="#">
                                OUR SERVICES
                            </a>
                            </center>
                        </div>
                    </div>
                    <div class="col-12 col-md-1"></div>
                    <div class="col-12 col-md-5">
                        <div class="row">
                            <div class="col-12 col-md-12 my-5">
                                <i class="bi bi-building-fill p-2 bisizes"></i>
                                    <span class="colort">Building Staffs</span>
                                <br>
                                    <small>
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut
                                        elit tellus, luctus nec ullamcorper mattis, pulvinar.
                                    </small>
                                <br><br><br>
                                <i class="bi bi-clipboard-check-fill p-2 bisizes"></i>
                                    <span class="colort">History Emphasis</span>
                                <br>
                                    <small>
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut
                                        elit tellus, luctus nec ullamcorper mattis, pulvinar.
                                    </small>
                                <br><br><br>
                                <i class="bi bi-house-fill p-2 bisizes"></i>
                                    <span class="colort">Economic Outcomes</span>
                                <br>
                                    <small>
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut
                                        elit tellus, luctus nec ullamcorper mattis, pulvinar.
                                    </small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <div class="row img-div2">
                    <div class="col-12 col-md-3 fourcol my-3">
                        <i class="bi bi-currency-dollar p-2 bisizes"></i>    
                        <b class="nmrsize">325</b>  
                        <br>
                        <small class="fourcol">Revenue in 2017 (Million)</small>
                    </div>
                    <div class="col-12 col-md-3 fourcol my-3">
                        <i class="bi bi-people-fill p-2 bisizes"></i>
                        <b class="nmrsize">525</b>
                        <br>
                        <small>Collaegues & Counting</small>
                    </div>
                    <div class="col-12 col-md-3 fourcol my-3">
                        <i class="bi bi-diagram-3-fill p-2 bisizes"></i>
                        <b class="nmrsize">302</b>
                        <br>
                        <small>Successfully Project</small>
                    </div>
                    <div class="col-12 col-md-3 fourcol my-3">
                        <i class="bi bi-award p-2 bisizes"></i>
                        <b class="nmrsize">25</b>
                        <br>
                        <small>Year of experience</small>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-12 my-5">
                        <center>
                            <b class="colortteam">The Team</b>
                            <br>
                            <b class="sizeexperts">Our Experts</b>
                        </center>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-1"></div>
                    <div class="col-12 col-md-10">
                        <div class="row">
                            <div class="col-12 col-md-3">
                                <center>
                                    <img src="img/about/person1.PNG" class="img-fluid">
                                </center>
                            </div>
                            <div class="col-12 col-md-3">
                                <center>
                                    <img src="img/about/person2.PNG" class="img-fluid">
                                </center>
                            </div>
                            <div class="col-12 col-md-3">
                                <center>
                                    <img src="img/about/person3.PNG" class="img-fluid">
                                </center>
                            </div>
                            <div class="col-12 col-md-3">
                                <center>
                                    <img src="img/about/person4.PNG" class="img-fluid">
                                </center>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-1"></div>
                </div>
            </div>
            <div class="container-fluid my-5">
                <div class="row">
                    <div class="col-12 col-md-6 bg1-div3">
                        <div class="mar-bg-div3">
                            <div class="sub-title-div3 mx-5">
                                <b>Sustainability</b> 
                            </div>
                            <div class="title-div3 mx-5">
                                <b>Committed To Keep <br> People Healthy & Safe</b> 
                            </div>
                            <div class="text-div3 mx-5 my-3">
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque<br> in  ipsum id orci porta dapibus.
                            </div>
                            <div class="getatouch-div3 p-2 w-25 mx-5 my-5">
                                <a href="services.php">
                                    <center>
                                        GET A TOUCH
                                    </center>
                                </a> 
                            </div>    
                        </div>
                    </div>
                    <div class="col-12 col-md-6 bg2-div3">
                        <div class="mar-bg-div3">
                            <div class="mini-title-div3 mx-5">
                                <b>We Follow Best Practices</b> 
                            </div>
                            <div class="text-2-div3 mx-5 my-3">
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque<br> in  ipsum id orci porta dapibus.
                            </div>
                            <div class="mini-table mx-5">
                                <div class="my-3">
                                    <b><i class="bi bi-recycle"></i> Sustainablility <br></b> 
                                </div>
                                <div class="my-3">
                                    <b><i class="bi bi-clock-fill"></i> Project On Time <br></b> 
                                </div>
                                <div class="my-3">
                                    <b><i class="bi bi-display"></i> Modern Technology <br></b>
                                </div>
                                <div class="my-3">
                                    <b><i class="bi bi-pencil-fill"></i> Latest Designs</b> 
                                </div>
                            </div>   
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-md-12 my-5">
                     <center>
                        <b class="colortservices2">Trust and Worth</b>
                        <br>
                        <b class="sizequality2">Our Clientes</b>
                    </center>
                </div>
            </div>
            <div class="row">
                 <center>
                <img class="img-fluid w-75" src="img/services/sponsor.png">
                </center>
            </div>
         </div>


        <div id="carouselExample" class="carousel slide">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="..." class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                    <img src="..." class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                    <img src="..." class="d-block w-100" alt="...">
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
        </main>
    <!-- FOOTER -->
        <footer>
            <?php include('hfconnectors/footer.php') ?>
        </footer>
    <!-- JAVASCRIPT -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <!-- LOADING SCREEN -->
        <div class="loader"></div>
        <script src="js/loader.js"></script>
    <!-- SCROLL ANIMATION-->
        <script src="js/scroll.js"></script>
</body>
</html>