<!DOCTYPE html>
<html lang="en">
<head>
    <!-- HEAD -->
    <!-- META -->
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- TITLE -->
        <title>Construction</title>
    <!-- CSS / ICONS -->
        <link rel="shortcut icon" href="img/logo_favicon.png">
        <link rel="stylesheet" href="../css/style.css">
        <link rel="stylesheet" href="../css/footer.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
</head>
<body>
    <footer>
        <div class="bg-footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-2"></div>
                    <div class="col-12 col-md-2">
                        <div class="footer-title mt-5 mb-3">
                            <b>Build With Urban Nest</b> 
                        </div>
                        <div class="footer-text mb-5">
                            Lorem ipsum dolor sit amet, <br> consectetur adipiscing elit. <br> Pellentesque in ipsum id orc.
                        </div>
                        <div class="footer-text mb-5">
                            Mon - Sat 8:00 - 17:30, <br> Sunday - CLOSED
                        </div>
                    </div>
                    <div class="col-12 col-md-2">
                        <div class="footer-title mt-5 mb-3">
                            <b>Our Services</b> 
                        </div>
                        <div class="footer-text mb-5">
                            Chemical Engineering Projects <br>
                            Mining Engineering Construction <br>
                            Engineering Welding Engineering <br>
                            Welding Engineering <br>
                            Space Program XYZ
                        </div>
                    </div>
                    <div class="col-12 col-md-2">
                        <div class="footer-title mt-5 mb-3">
                            <b>Office in Canada</b> 
                        </div>
                        <div class="footer-text mb-5">
                            7300-7398 Colonial Rd, <br> Brooklyn, NY 11209
                        </div>
                        <div class="footer-text mb-5">
                            (123) 1234-567-8901 <br> contact@example.com
                        </div>
                    </div>
                    <div class="col-12 col-md-2">
                        <div class="footer-title mt-5 mb-3">
                            <b>Our Locations</b> 
                        </div>
                        <div class="footer-text mb-5">
                        United States <br>
                        Australia <br>
                        Canada <br>
                        Europe
                        </div>
                    </div>
                    <div class="col-12 col-md-2"></div>
                    <hr class="hr-footer">
                </div>
                <div class="row">
                    <div class="col-12 col-md-1"></div>
                    <div class="col-12 col-md-10 my-4">
                        <div class="copyright float-start">
                            Copyright © 2023
                        </div>
                        <div class="footer-social float-end">
                            <a href="#"><i class="bi bi-facebook"></i></a>
                            <a href="#"><i class="bi bi-twitter"></i></a>
                            <a href="#"><i class="bi bi-instagram"></i></a>
                            <a href="#"><i class="bi bi-linkedin"></i></a>
                        </div> 
                    </div>
                    <div class="col-12 col-md-1"></div>
                </div>
            </div>    
        </div>
        
    </footer>
</body>
</html>